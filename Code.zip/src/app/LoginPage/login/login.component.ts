import { Component, OnInit } from '@angular/core';
import { AlertsModule } from 'angular-alert-module';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { CommonServiceService } from './../../services/common-service.service'
import { ILoginDetails } from '../../models/common/common.component';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginUser :ILoginDetails [] =[{
    userName:"",
    password:""
  }]

  constructor(private spinner: NgxSpinnerService,private appServices: CommonServiceService,private router:Router) { }

  userSubmitted: boolean = false;
  userLoginDetails:any=[];

  ngOnInit(): void{
  
  }

userSubmit(loginUser)
{ 
  this.spinner.show();  
 let user = loginUser;

 if(user.userName!='' && user.userName!=null && user.password!='' && user.password!=null)
    {  
       var vUser = { 
          Action: "CheckLogin",
          UserDetail :
          {
            userName : user.userName,
            password: user.password    
          }
       }

      // var vUser = {
      //   userName : user.userName,
      //   password: user.password        
      // };

       //this.appServices.getLoginDetails(vUser).subscribe(data => {

      this.appServices.callCommonService(vUser).subscribe(data => {
            
        console.log(data);
        this.userLoginDetails = data;

        if(this.userLoginDetails!=null)
        {
        if(this.userLoginDetails.IsSuccess == true)
            this.router.navigateByUrl('/customerDetail');  
          else
            Swal('Failed', 'Login failed.User is not valid!.', 'error');  
            
            this.spinner.hide();
        }
          else{
            Swal('Failed', 'Login failed.User is not valid!.', 'error');  
            
            this.spinner.hide();
          } 

          });  
    }
    else{
        Swal('Failed', 'Please Enter UserName and Password', 'error');
        this.spinner.hide();
    }
  };
 
};