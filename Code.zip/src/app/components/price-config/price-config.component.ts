import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonServiceService } from '../../services/common-service.service'; 
import { OrderPipe, OrderModule } from 'ngx-order-pipe';
import { PagerService } from  '../../services/pageService';
import Swal from 'sweetalert2';
import { IPriceDetails } from '../../models/common/common.component';

@Component({
  selector: 'app-price-config',
  templateUrl: './price-config.component.html',
  styleUrls: ['./price-config.component.css']
})
export class PriceConfigComponent implements OnInit {

  priceDetail :IPriceDetails [] =[{
    typeId:0,
    price:0   
  }]

  constructor(private spinner: NgxSpinnerService,private appServices: CommonServiceService) { }

  ddlTypes: any = []; 
  ddlTypesList:any=[]; 
  priceTypesList:any=[]; 
  resultDetails: any =[]; 

  priceJson = [
       {
        "typeList": [
            {
                "typeId": 1,
                "typeName": "0.5L"
            },
            {
                "typeId": 2,
                "typeName": "1L"
            }
        ],
        "priceList": [
            {
                "priceId": 0,
                "typeId": 1,
                "price": 15,
                "priceChangedDate": "2018-12-15T19:16:58",
                "createdDate": "0001-01-01T00:00:00",
                "createdBy": 0,
                "modifiedBy": 0,
                "isActive": false
            },
            {
                "priceId": 0,
                "typeId": 2,
                "price": 50,
                "priceChangedDate": "2018-12-19T08:07:33",
                "createdDate": "0001-01-01T00:00:00",
                "createdBy": 0,
                "modifiedBy": 0,
                "isActive": false
            }            
        ],
        "smsList": null,
        "resMessage": null,
        "totCount": 3,
        "isSuccess": true
    }
    ];


  ngOnInit() {

   var ddlData = this.getType();    
  }

  public getType()
  {
    this.spinner.show();   

    var vGetTypes = { 
      Action: "GetTypeDetail"    
   }

    // this.ddlTypes=this.priceJson[0];

    //     if(this.ddlTypes !=null)
    //     {          
    //         this.ddlTypesList=this.ddlTypes.typeList;
    //         this.priceTypesList=this.ddlTypes.priceList;
    //        this.spinner.hide();          
    //     }
    //     else{
    //       this.spinner.hide();
    //     } 

    this.appServices.callCommonService(vGetTypes).subscribe(data => {
                     
       this.ddlTypes = data;

        if(this.ddlTypes !=null)
        {
          if(this.ddlTypes.IsSuccess)
          {
            this.ddlTypesList=this.ddlTypes.lstTypeDetail;
            this.priceTypesList=this.ddlTypes.lstPriceDetail;
            this.spinner.hide();
          } 
          else{
            this.spinner.hide();   
          }
        } 
        else
        this.spinner.hide();     
      }); 
      
  };

  public priceSubmit(priceConfig)
  {
    this.spinner.show();   

    if (priceConfig!=undefined) {  

      if(priceConfig.typeId!=null && priceConfig.typeId!='' 
      && priceConfig.price!=null && priceConfig.price!='')
      {
        var vCustForm = {
          Action: "AddPrice",
          PriceDetail:
          {    
            typeId: priceConfig.typeId,
            price: priceConfig.price    
          }         
        };
  
        this.appServices.callCommonService(vCustForm).subscribe(data => {
          this.resultDetails=data;
            if(this.resultDetails.IsSuccess)
          {
            Swal('success', `Price added successfully...`, 'success');
            this.getType();
            this.ResetPriceConfig();
            this.spinner.hide();
          }
          this.spinner.hide();
        });
      }
        else {
          Swal('Failed', 'Please try again..', 'error');
          this.spinner.hide();
        }
      } 
      else
      {
        Swal('Failed', 'All fields are mandatory.', 'error');
        this.spinner.hide();
      }

  };

  onlyDecimalNumberKey(event) {
    let charCode = (event.which) ? event.which : event.keyCode;
    if (charCode != 46 && charCode > 31
        && (charCode < 48 || charCode > 57))
        return false;
    return true;
  };

  public ResetPriceConfig()
  {
    this.priceDetail =[];
  };
}
