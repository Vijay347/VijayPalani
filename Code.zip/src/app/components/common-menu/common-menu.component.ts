import { Component, OnInit } from '@angular/core';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { Router } from '@angular/router';

@Component({
  selector: 'app-common-menu',
  templateUrl: './common-menu.component.html',
  styleUrls: ['./common-menu.component.css']

})
export class CommonMenuComponent implements OnInit {

  constructor(private router:Router) { }
 
  public ngOnInit() {
   
  }
}
