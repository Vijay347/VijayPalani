import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonServiceService } from '../../services/common-service.service'; 
import { OrderPipe, OrderModule } from 'ngx-order-pipe';
import { PagerService } from  '../../services/pageService';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {

  list:any= []; 
  productList:any=[]; 
  search: any = {
    custSearch: '',
    startDate:'',
    endDate:''
  }
  constructor(private spinner: NgxSpinnerService,private appServices: CommonServiceService) { }

  ngOnInit() {
    var vlist = this.getProductDetail();
  }


  public getProductDetail()
  {
    this.spinner.show();   

    var vGetProduct = { 
      Action: "GetProduct"    
   }

    this.appServices.callCommonService(vGetProduct).subscribe(data => {
                     
      this.list = data;

        if(this.list !=null)
        {
          if(this.list.IsSuccess)
          {
            this.productList=this.list.lstCustomerDetail;
            console.log(this.list.lstCustomerDetail);
            this.spinner.hide();
          } 
          else{
            this.spinner.hide();   
          }
        } 
        else
        this.spinner.hide();     
      }); 
      
  };
}


// address: null
// balance: 0
// credit: 0
// creditedDate: "2019-02-10T00:00:00"
// custNamePhone: "Sandhiya - 9750457250"
// customerId: 4
// customerName: "Sandhiya"
// debit: 0
// ledgerId: 0
// modifiedDate: null
// phone: "9750457250"
// reason: null
// userId: 0
// userToken: null

// address: null
// balance: 400
// credit: 200
// creditedDate: "2019-02-04T09:29:21"
// custNamePhone: "Testing - 1231231232"
// customerId: 2
// customerName: "Testing"
// debit: 0
// ledgerId: 0
// modifiedDate: null
// phone: "1231231232"
// reason: null
// userId: 0
// userToken: null