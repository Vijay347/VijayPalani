import { Component, OnInit } from '@angular/core';
import { Router ,ActivatedRoute} from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonServiceService } from '../../services/common-service.service'; 

@Component({
  selector: 'app-view-customer',
  templateUrl: './view-customer.component.html',
  styleUrls: ['./view-customer.component.css']
})
export class ViewCustomerComponent implements OnInit {

  constructor(private spinner: NgxSpinnerService,private appServices: CommonServiceService,private router:Router,private activatedRoute: ActivatedRoute) { }

  customerDetails: any =[]; 
  customerList: any = []; 
  custName:string='';

  ngOnInit() {
    let custID = this.activatedRoute.snapshot.paramMap.get('id');
    this.getCustDetails(custID);
  }

  getCustDetails(custID)
  {
    this.spinner.show();  
    
    var vCustForm = {
      Action: "GetSpecificCustomer",
      CustomerDetail:
      {    
        customerId : custID       
      }         
    };
        
    this.appServices.callCommonService(vCustForm).subscribe(data => {
       this.customerDetails = data;

        if(this.customerDetails !=null)
        {
          if(this.customerDetails.IsSuccess)
          {
            this.customerList=this.customerDetails.lstCustomerDetail;
            this.custName=this.customerDetails.lstCustomerDetail[0].customerName;
            this.spinner.hide();
          } 
          else
            this.spinner.hide();
        } 
        else
          this.spinner.hide();
      });      
     
    };


    BackCustomer()
    {
      this.router.navigateByUrl('/customerDetail');   
    }

}
