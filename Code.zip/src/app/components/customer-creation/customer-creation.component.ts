import { Component, OnInit, AfterViewInit,Injectable } from '@angular/core';
import Swal from 'sweetalert2';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonServiceService } from '../../services/common-service.service'; 
import { Router ,ActivatedRoute} from '@angular/router';
import { ICustomerDetails } from '../../models/common/common.component';
import { CustomerDetailComponent } from '../customer-detail/customer-detail.component'

@Component({
  selector: 'app-customer-creation',  
  templateUrl: './customer-creation.component.html',
  styleUrls: ['./customer-creation.component.css']  
})


export class CustomerCreationComponent implements OnInit   {


  custJson = [
    {
      "custDetailList": [
          {
            "customerId": 1,
              "customerName": "Vijay",
              "phone": 1234567890,
              "credit": 100,
              "balance": 50,
              "address":"test"
          },
          {
            "customerId": 2,
            "customerName": "Tej",
            "phone": 1234567891,
            "credit": 10,
            "balance": 10,
            "address":"test1"
          }
      ],    
  } 
];
  
  custDetail :ICustomerDetails  ={
    customerId:0,
    customerName:"",  
    phone:0,   
    address:"",
    credit:0 
  }

  constructor(private spinner: NgxSpinnerService,private appServices: CommonServiceService,private router:Router,private activatedRoute: ActivatedRoute) { 
    
  
  } 

  customerDetails: any =[]; 
  customerList: any = []; 
  customerID:string='0';
  resultDetails: any =[]; 

  ngOnInit() {   

    this.customerID = this.activatedRoute.snapshot.paramMap.get('id');

    if(this.customerID!='0')
      this.getCustDetails(this.customerID);
    else
      this.getCustDetails(0);
  }

  onlyNumberKey(event) {
    return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
}

onlyDecimalNumberKey(event) {
  let charCode = (event.which) ? event.which : event.keyCode;
  if (charCode != 46 && charCode > 31
      && (charCode < 48 || charCode > 57))
      return false;
  return true;
}

  customerSubmit(custDetail) {
  
    this.spinner.show();     
    
    if(custDetail.customerName !=null && custDetail.customerName !="")
      {       
      if(custDetail.phone.length!=10)
        {
          Swal('Failed', 'Phone number should be 10 digits', 'error');
          this.spinner.hide();
        }
        else{

          var vCustForm = {
            Action: "AddCustomer",
            CustomerDetail:
            {    
              customerId : this.customerID,
              customerName: custDetail.customerName,
              phone: custDetail.phone, 
              address: custDetail.address,
              credit: 0   
            }         
          };

            this.appServices.callCommonService(vCustForm).subscribe(data => {
              if (data) {
                  this.resultDetails=data;
                    if(this.resultDetails.IsSuccess)
                    {
                      Swal('success', `Customer details submitted successfully`, 'success');
                      this.router.navigateByUrl('/customerDetail');
                      this.spinner.hide();
                    }
                    else{
                      Swal('Failed',  this.resultDetails.Message, 'error');
                      this.spinner.hide();
                    }
              }
              else {
                Swal('Failed', 'Please try again..', 'error');
                this.spinner.hide();
              }
            });

          }         
      }
      else{        
        Swal('Failed', 'All fields are mandatory.', 'error');
        this.spinner.hide();
      }
     };

    BackCustomer()
    {
      this.router.navigateByUrl('/customerDetail');   
    }

   getCustDetails(custID)
  {
    this.spinner.show();  
    
    if(custID !=0)
    {
      var vGetCustomer = { 
        Action: "GetCustomerDetail"    
     }

       // this.customerDetails=this.custJson[0];

        // if(this.customerDetails !=null)
        // { 
        //   let vList =this.customerDetails.custDetailList;
        //   for (let i = 0; i < vList.length; i++) {
        //     if (vList[i].customerId == custID) {
        //         this.customerList= vList[i];
        //         this.custDetail=this.customerList;
        //     }
        // } 

        //     this.spinner.hide();          
        // }
        // else{
        //   this.spinner.hide();
        // } 

        this.appServices.callCommonService(vGetCustomer).subscribe(data => {
          this.customerDetails = data;
           if(this.customerDetails !=null)
           {
             if(this.customerDetails.IsSuccess)
             {
               let vList =this.customerDetails.lstCustomerDetail;
               for (let i = 0; i < vList.length; i++) {
                 if (vList[i].customerId == custID) {
                     this.customerList= vList[i];
                     this.custDetail=this.customerList;
                      this.custDetail.credit = this.customerList.balance 
                 }
               }
              // this.customerList=this.customerDetails.customerList;
               this.spinner.hide();
             } 
             else
               this.spinner.hide();
           } 
           else
             this.spinner.hide();
         });   
    }        
       else{

        this.custDetail.customerId=0;
        this.custDetail.customerName="";
        this.custDetail.address="";
        this.custDetail.phone=0;
        this.custDetail.credit=0;

        this.custDetail = this.custDetail;
        this.spinner.hide();
       }   
     
    };

    
  };