import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    if (args.AllCustSearch) {
      value = value.filter(custList => custList.customerName.toLowerCase().indexOf(args.AllCustSearch.toLowerCase()) != -1);
    }

    if (args.StartDateSearch) {
      value = value.filter(product => product.creditedDate.toLowerCase().indexOf(args.StartDateSearch.toLowerCase()) != -1);
    }

    if (args.EndDateSearch) {
      value = value.filter(product => product.creditedDate.toLowerCase().indexOf(args.EndDateSearch.toLowerCase()) != -1);
    }

    return value;

  }

}
