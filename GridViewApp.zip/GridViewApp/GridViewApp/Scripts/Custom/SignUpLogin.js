﻿$(document).ready(function () {
    var Uurl = "http://localhost:64342/";
    var vAction = 'insert';
    var vUserLoginId = 0;
    var vCount = 0;

    LoginSubmit = function () {
        var UserName = $("#txtUserName").val()
        var Designation = $("#txtDesignation").val();
        var DOB = $("#txtDateOfBirth").val();
        var Password = $("#txtPassword").val();
        var ConfirmPassword = $("#txtConfirmPassword").val();
        var Active = $("#checkbox").val();


        if ($("#checkbox").is(':checked'))
            Active = 1;
        else
            Active = 0;

        if (UserName == "" || UserName == null || Password == "" || Password == null || Designation == "" || Designation == null || DOB == "" || DOB == null || ConfirmPassword == "" || ConfirmPassword == null) {

            if (UserName != null && UserName != "") {
                $("#ErrUserName").text("");
            }
            else {
                $("#ErrUserName").text("UserName Required");
            }
            if (Password != "" && Password != null) {
                $("#ErrPassword").text("");
            }
            else {
                $("#ErrPassword").text("Password Required");
            }
            if (Designation != null && Designation != "") {
                $("#ErrDesignation").text("");
            }
            else {
                $("#ErrDesignation").text("Designation Required");
            }
            if (DOB != null && DOB != "") {
                $("#ErrDateOfBirth").text("");
            }
            else {
                $("#ErrDateOfBirth").text("DateOfBirth Required");
            }
            if (ConfirmPassword != null && ConfirmPassword != "") {
                $("#ErrConfirmPassword").text("");
            }
            else {
                $("#ErrConfirmPassword").text("Confirm Password Required");
            }

        }
        else {
            if (Password.length < 8) {
                $("#ErrPassword").text("Atleast contain 8 characters");
            }
            else {
                if (Password.match(/([a-zA-Z])/) && Password.match(/([0-9])/) && Password.match(/([!,%,&,@,#,$,^,*,?,_,~])/)) {
                    $("#ErrPassword").text("");

                    if (Password == ConfirmPassword) {
                        var UserLogindetails =
                            {
                                UserLoginId: vUserLoginId,
                                UserName: UserName,
                                Active: Active,
                                Designation: Designation,
                                DOB: DOB,
                                Password: Password,
                                Action: vAction,


                            }
                        //if (vCount == 0) {
                        //    alert("UserName Already Exists");

                        //}
                        //else {

                        $.ajax({
                            url: Uurl + "Home/SignUpLogin",
                            type: 'Post',
                            data: {
                                uslo: UserLogindetails
                            },

                            success: function (data) {
                                if (data != null) {
                                    if (data.res) {
                                        if (data.result == 0) {
                                            if (vUserLoginId == 0) {


                                                alert("Submitted Succesfully");
                                                clearValues();
                                                window.location.reload();
                                            }


                                            else {

                                                alert('Updated Successfully');
                                                clearValues();
                                                window.location.reload();

                                            }
                                        } else {
                                            alert("Username Already Exists");
                                        }

                                    }
                                    else {
                                        alert(data.res);
                                    }
                                }

                            },
                            error: function () {
                            }


                        });
                    }
                        //  }
                    else {
                        $("#ErrConfirmPassword").text("Password and confirm password should be same");
                    }

                }
                else {
                    $("#ErrPassword").text("Password contain Uppercase,lowercase,special char,Number");
                }
            }
        }

    }

    function GetData(id) {
        $.ajax({
            url: Uurl + "Home/GridView",
            type: 'Post',

            data: {
                id: id
            },

            success: function (data) {

                if (data != null) {
                    var vUserDetail = jQuery.parseJSON(data);
                    if (id != 0) {
                        var username = vUserDetail[0].UserName;
                        $("#txtUserName").val(vUserDetail[0].UserName).prop("disabled", true);
                        $("#txtDesignation").val(vUserDetail[0].Designation);
                        var Birthdate = moment(vUserDetail[0].DOB).format('YYYY-MM-DD');
                        $("#txtDateOfBirth").val(Birthdate).prop("disabled", true);
                        $("#txtPassword").val(vUserDetail[0].Password);
                        $("#txtConfirmPassword").val(vUserDetail[0].Password);
                        var chk = vUserDetail[0].Active;
                        if (chk == true) {
                            $("#checkbox").prop('checked', true);
                        }
                        else {
                            $("#checkbox").prop('checked', false);
                        }
                    }
                }
            },
            error: function () {

            }
        });
    }

    GetData(0);

    Edit = function (id) {
        $("#Submit").text("Update");

        GetData(id);
        vAction = 'update';
        vUserLoginId = id;
    };




    Delete = function (id) {
        var choice = confirm("Do you really want to  Delete this Row");
        if (choice == true) {
            $.ajax({
                url: Uurl + "Home/DeleteRow",
                type: "Post",
                data: {

                    id: id
                },
                success: function (data) {



                },
                error: function () {

                }


            });
            setTimeout(
        function () {
            location.reload();
        }, 100
        );
            alert("Deleted successfully");
        }
        else {
            alert("Cancelled");
        }

    }

    clearValues = function () {
        $("#txtUserName").val("");
        $("#txtDesignation").val("");
        $("#txtDateOfBirth").val("");
        $("#txtPassword").val("");
        $("#txtConfirmPassword").val("");
        $("#ErrUserName").text("");
        $("#ErrPassword").text("");
        $("#ErrDesignation").text("");
        $("#ErrDateOfBirth").text("");
        $("#ErrConfirmPassword").text("");
        $("#checkbox").prop('checked', false);
        $("#txtUserName").prop("disabled", false);
        $("#txtDateOfBirth").prop("disabled", false);
        var vUserLoginId = 0;

        vAction = "insert";
        $("#Submit").text("Submit");
    }
});







//var dtToday = new Date();

//var month = dtToday.getMonth() + 1;
//var day = dtToday.getDate();
//var year = dtToday.getFullYear();
//if (month < 10)
//    month = '0' + month.toString();
//if (day < 10)
//    day = '0' + day.toString();

//var maxDate = year + '-' + month + '-' + day;