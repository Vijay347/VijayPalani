﻿$(document).ready(function () {
    var Uurl = "http://localhost:64342/";
    var vAction = 'insert';
    var vUserLoginId = 0;
    var vCount = 0;
    var counter = 1;
    var Count = 0;
    var k = 0;
    var page = 1;
    $("#num").val("1");

    Search = function () {
        var Username = $("#UserNamefil").val();
        var Designation = $("#Designationfil").val();
        $.ajax({
            url: Uurl + "Home/Searching",
            type: 'Post',
            data: {
                Usernamefilter: Username,
                Designationfilter:Designation

            },
            success: function (data) {
                $("#PartialSignUp").html(data);

            },
            error: function () {

            }
        });
    };
    Filter = function () {
        var Username = $("#Search").val();
        if (Username.length >= 3) {

            $.ajax({
                url: Uurl + "Home/Filtering",
                type: 'Post',
                data: {
                    UsernameSearch: Username,

                },
                success: function (data) {
                    $("#PartialSignUp").html(data);

                },
                error: function () {

                }
            });
        }
        else if (Username.length == 0) {
            $.ajax({
                url: Uurl + "Home/Filtering",
                type: 'Post',
                data: {
                    UsernameSearch: Username,

                },
                success: function (data) {
                    $("#PartialSignUp").html(data);

                },
                error: function () {

                }
            });

        }
    };

    Sorting = function (columnname,sort) {
        $.ajax({
            url: Uurl + "Home/Sorting",
            type: 'Post',
            data: {
                ColumnName: columnname,
                Sort: sort

            },
            success: function (data) {
                $("#PartialSignUp").html(data)
                
            },
            error: function () {

            }
        });
    };

    $("#previous").prop("disabled", true);

    Partialview = function (page) {
        $.ajax({
            url: Uurl + "Home/GetRecords",
            type: 'Post',
            data: {
                page: page
            },
            success: function (data) {
                $("#PartialSignUp").html(data)
            },
            error: function () {

            }
        });
    };
    Partialview(page);
    Change = function () {
        k = Math.ceil(Count / 5);
        var c = $("#num").val();
        if (c > k || c<=0) {
            alert("No Results Found");
            //$("#previous").prop("disabled", true);
            //$("#next").prop("disabled", true);
          
        }
        else {
            $("#num").text(c);
            Partialview(c);
        }
    };

    $.ajax({
        url: Uurl + "Home/GetDropDownList",
        type: 'Post',
        data: {

        },
        success: function (data) {
            if (data != null) {
                var gd = jQuery.parseJSON(data);

                for (var i = 0; i < gd.length; i++) {
                    var opt = '<option value="' + gd[i].Id + '">' + gd[i].Name + '</option>';
                    $("#txtDesignation").append(opt);
                }
            }
        },
        error: function () {

        }
    });

    Next = function () {
        k = Math.ceil(Count / 5);
        $("#n2").text(k);
        var p = $("#num").val();
        if (p == k) {
            $("#next").prop("disabled", true);
            next = k;

          
        }
        else {
            //counter = parseInt($("#hiddenVal").val());
            counter = $("#num").val();

            counter++;
            $("#next").val(counter);
            var next = $("#next").val();

            if (next <= k) {

                $("#num").val(next);

            }
        }
        Partialview(next);
        //$.ajax({
        //    url: Uurl + "Home/GetRecords",
        //    type: 'Post',
        //    data: {
        //        page: next
        //    },
        //    success: function (data) {
        //        $("#PartialViewSignUp").html(data)
        //    },
        //    error: function () {

        //    }
        //});

    }
    Previous = function () {
        //counter = parseInt($("#hiddenVal").val());
        counter = $("#num").val();
        if (counter > 1 && counter<=k) {
            counter--;
            $("#previous").val(counter);
            var prev = $("#previous").val();

            if (prev <= k)

                $("#num").val(prev);
            Partialview(prev);
            //$.ajax({
            //    url: Uurl + "Home/GetRecords",
            //    type: 'Post',
            //    data: {
            //        page: prev
            //    },
            //    success: function (data) {
            //        $("#PartialViewSignUp").html(data)
            //    },
            //    error: function () {

            //    }
            //});
        }
        else {
            $("#previous").prop("disabled", true);

        }

    }


    var now = new Date();
    maxDate = now.toISOString().substring(0, 10);
    $('#txtDateOfBirth').attr('max', maxDate);


    LoginSubmit = function () {
        var UserName = $("#txtUserName").val()
        var Designation = $("#txtDesignation").val();
        var DOB = $("#txtDateOfBirth").val();
        var Password = $("#txtPassword").val();
        var ConfirmPassword = $("#txtConfirmPassword").val();
        var Active = $("#checkbox").val();


        if ($("#checkbox").is(':checked'))
            Active = 1;
        else
            Active = 0;

        if (UserName == "" || UserName == null || Password == "" || Password == null || Designation == "" || Designation == null || DOB == "" || DOB == null || ConfirmPassword == "" || ConfirmPassword == null) {

            if (UserName != null && UserName != "") {
                $("#ErrUserName").text("");
            }
            else {
                $("#ErrUserName").text("UserName Required");
            }
            if (Password != "" && Password != null) {
                $("#ErrPassword").text("");
            }
            else {
                $("#ErrPassword").text("Password Required");
            }
            if (Designation != null && Designation != "" && Designation!=0) {
                $("#ErrDesignation").text("");
            }
            else if(Designation==0){
                $("#ErrDesignation").text("Designation Required");
            }
            if (DOB != null && DOB != "") {
                $("#ErrDateOfBirth").text("");
            }
            else {
                $("#ErrDateOfBirth").text("DateOfBirth Required");
            }
            if (ConfirmPassword != null && ConfirmPassword != "") {
                $("#ErrConfirmPassword").text("");
            }
            else {
                $("#ErrConfirmPassword").text("Confirm Password Required");
            }

        }
        else {
            if (Password.length < 8) {
                $("#ErrPassword").text("Atleast contain 8 characters");
            }
            else {
                if (Password.match(/([a-zA-Z])/) && Password.match(/([0-9])/) && Password.match(/([!,%,&,@,#,$,^,*,?,_,~])/)) {
                    $("#ErrPassword").text("");

                    if (Password == ConfirmPassword) {
                        var UserLogindetails =
                            {
                                UserLoginId: vUserLoginId,
                                UserName: UserName,
                                Active: Active,
                                Designation: Designation,
                                DOB: DOB,
                                Password: Password,
                                Action: vAction,


                            }
                        $.ajax({
                            url: Uurl + "Home/SignUpLogin",
                            type: 'Post',
                            data: {
                                uslo: UserLogindetails
                            },

                            success: function (data) {
                                if (data != null) {
                                    if (data.res) {
                                        if (data.result == 0) {
                                            if (vUserLoginId == 0) {
                                                alert("Submitted Succesfully");
                                                clearValues();
                                                window.location.reload();
                                            }

                                            else {

                                                alert('Updated Successfully');
                                                clearValues();
                                                window.location.reload();

                                            }
                                        } else {
                                            alert("Username Already Exists");
                                        }

                                    }
                                    else {
                                        alert(data.res);
                                    }
                                }

                            },
                            error: function () {
                            }


                        });
                    }

                    else {
                        $("#ErrConfirmPassword").text("Password and confirm password should be same");
                    }

                }
                else {
                    $("#ErrPassword").text("Password contain Uppercase,lowercase,special char,Number");
                }
            }
        }

    }

    function GetData(id) {
        $.ajax({
            url: Uurl + "Home/GridView",
            type: 'Post',

            data: {
                id: id
            },

            success: function (data) {
                console.log(data.result);
                Count = data.count;

                if (data != null) {
                    var vUserDetail = jQuery.parseJSON(data.result);
                    if (id != 0) {
                        var username = vUserDetail[0].UserName;
                        $("#txtUserName").val(vUserDetail[0].UserName).prop("disabled", true);
                        $("#txtDesignation")[0].selectedIndex = vUserDetail[0].Id;
                        var Birthdate = moment(vUserDetail[0].DOB).format('YYYY-MM-DD');
                        $("#txtDateOfBirth").val(Birthdate).prop("disabled", true);
                        $("#txtPassword").val(vUserDetail[0].Password);
                        $("#txtConfirmPassword").val(vUserDetail[0].Password);
                        var chk = vUserDetail[0].Active;
                        if (chk == true) {
                            $("#checkbox").prop('checked', true);
                        }
                        else {
                            $("#checkbox").prop('checked', false);
                        }
                    }
                }
             
            },
            error: function () {

            }
        });
        
    }

    GetData(0);

    Edit = function (id) {
        $("#Submit").text("Update");

        GetData(id);
        vAction = 'update';
        vUserLoginId = id;
    };
    Delete = function (id) {
        var choice = confirm("Do you really want to  Delete this Row");
        if (choice == true) {
            $.ajax({
                url: Uurl + "Home/DeleteRow",
                type: "Post",
                data: {

                    id: id
                },
                success: function (data) {



                },
                error: function () {

                }


            });
            setTimeout(
        function () {
            location.reload();
        }, 100
        );
            alert("Deleted successfully");
        }
        else {
            alert("Cancelled");
        }

    }

    clearValues = function () {
        $("#txtUserName").val("");
        $("#txtDesignation")[0].selectedIndex = 0;
        $("#txtDateOfBirth").val("");
        $("#txtPassword").val("");
        $("#txtConfirmPassword").val("");
        $("#ErrUserName").text("");
        $("#ErrPassword").text("");
        $("#ErrDesignation").text("");
        $("#ErrDateOfBirth").text("");
        $("#ErrConfirmPassword").text("");
        $("#checkbox").prop('checked', false);
        $("#txtUserName").prop("disabled", false);
        $("#txtDateOfBirth").prop("disabled", false);
        vUserLoginId = 0;
        vAction = "insert";
       
        GetData(0);
       
        $("#Submit").text("Submit");
    }
    $("#n1").text("1");
    $("#n2").text("3");
   
});








