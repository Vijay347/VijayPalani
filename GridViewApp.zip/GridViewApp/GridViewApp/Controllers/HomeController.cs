﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Data;
using Newtonsoft.Json;
using Utility;
using BusinessLayer;

namespace GridViewApp.Controllers
{
    public class HomeController : Controller
    {
        GridViewAppBL objBL = new GridViewAppBL();
      
        List<UserLogin> Listuser = new List<UserLogin>();
        List<UserLogin> value = new List<UserLogin>();
        // GET: Home


        public ActionResult SignUp()
        {
            //    DataSet ds = userlogin.GetValues1();
            //    ViewBag.data = ds;
            return View();


        }
        public ActionResult SignUpLogin(UserLogin uslo)
        {

            bool success = objBL.InsertingBL(uslo);
            byte k = uslo.isExists;

            return Json(new { res = success, result = k });
        }

        public ActionResult GridView(int id)
        {
            Listuser = objBL.GetValuesBL(id);

            var jsonob = JsonConvert.SerializeObject(Listuser);
            // return Json(new { res = Listuser });


            return Json(new { result = jsonob, count = Listuser.Count() });

        }
        public ActionResult DeleteRow(int id)
        {
            bool k = objBL.DeleteUserBL(id);
            return View();

        }
        public ActionResult GetDropDownList()
        {
            Listuser = objBL.DesignationBL();
            var jsonobj = JsonConvert.SerializeObject(Listuser);
            return Json(jsonobj);
            //return RedirectToAction("SignUp");
        }
        public ActionResult GetRecords(int? page)
        {
            if (page == null)
                page = 1;
            if (page > 0)
            {
                if (page == 1)
                {
                    Listuser = objBL.GetValuesBL(0);
                    Session["GridList"] = Listuser;
                    if (Session["GridList"] != null)
                    {
                        Listuser = Session["GridList"] as List<UserLogin>;
                        var total = Listuser.Count;
                        var pageSize = 5;
                        int? skip = pageSize * (page - 1);

                        if (skip < total)
                        {
                            value = Listuser.Skip(Convert.ToInt32(skip)).Take(pageSize).ToList();
                        }
                    }
                }
                else
                {
                    if (Session["GridList"] != null)
                    {
                        Listuser = Session["GridList"] as List<UserLogin>;
                        var total = Listuser.Count;
                        var pageSize = 5;
                        int? skip = pageSize * (page - 1);

                        if (skip < total)
                        {

                            value = Listuser.Skip(Convert.ToInt32(skip)).Take(pageSize).ToList();

                        }
                    }
                }
            }

            return PartialView("PartialViewSignUp", value);

        }
        public ActionResult GetLinqList()
        {
           
            DataSet ds = objBL.LinqBL();
            DataTable dt = ds.Tables[0];
            DataTable dt1 = ds.Tables[1];
            var sortedList = dt.AsEnumerable().OrderBy(r => r.Field<string>("UserName")).ToList().CopyToDataTable();
            var sortedList1 = dt1.AsEnumerable().OrderByDescending(r1 => r1.Field<int>("UserDetailId")).ToList().CopyToDataTable();
            var joinlist = from t1 in dt.AsEnumerable()
                           join t2 in dt1.AsEnumerable() on t1["UserLoginId"] equals t2["UserLoginId"]
                           select new
                           {
                               UserLoginId = t1["UserLoginId"],
                               UserName = t1["UserName"],
                               Active = t1["Active"],
                               Designation = t2["Designation"],
                               DOB = Convert.ToDateTime(t2["DOB"]).ToString("MM/yyyy"),
                               Password = t2["Password"],
                               UserDetailId = t2["UserDetailId"]
                           };
            var list = sortedList.AsEnumerable().Where(r => r.Field<string>("UserName").ToLower() == "supriya").CopyToDataTable();
            var jsonobj = JsonConvert.SerializeObject(sortedList);
            var jsonobj1 = JsonConvert.SerializeObject(sortedList1);
            var jsonobj2 = JsonConvert.SerializeObject(joinlist);
            var jsonobj3 = JsonConvert.SerializeObject(list);

            return Json(new { j = jsonobj, j1 = jsonobj1, j2 = jsonobj2, j3 = jsonobj3 });

        }
        public ActionResult GetLinqList1()
        {

            DataSet ds = objBL.LinqBL();
            UserLogin user = null;
            Listuser = new List<UserLogin>();
            value = new List<UserLogin>();
            DataTable dt = ds.Tables[0];
            DataTable dt1 = ds.Tables[1];

            if (ds != null)
            {
                foreach (DataRow r in dt.Rows)
                {

                    user = new UserLogin();
                    user.UserLoginId = Convert.ToInt32(r["UserLoginId"].ToString());
                    user.UserName = r["UserName"].ToString();
                    user.Active = Convert.ToByte(r["Active"].ToString() == "True" ? 1 : 0);
                    Listuser.Add(user);

                }
                foreach (DataRow r1 in dt1.Rows)
                {
                    user = new UserLogin();
                    user.UserLoginId = Convert.ToInt32(r1["UserLoginId"].ToString());
                    user.Password = r1["Password"].ToString();
                    user.Designation = r1["Designation"].ToString();
                    user.DOB = Convert.ToDateTime(r1["DOB"].ToString());
                    value.Add(user);

                }
            }
            var sortedlist = Listuser.OrderBy(r => r.UserLoginId);
            var sortedlist1 = value.OrderBy(r => r.UserDetailId);
            var joinList = from l in Listuser
                           join v in value on l.UserLoginId equals v.UserLoginId 
                           select new
                           {
                               l.UserLoginId,
                               l.UserName,
                               v.Designation,
                               v.DOB,
                               v.Password
                           };

            var jsonobj = JsonConvert.SerializeObject(sortedlist);
            var jsonobj1 = JsonConvert.SerializeObject(sortedlist1);
            var jsonobj2 = JsonConvert.SerializeObject(joinList);
            return Json(new { j = jsonobj, j1 = jsonobj1, j2 = jsonobj2 });

        }
        public ActionResult Sorting(string ColumnName,string Sort)
        {
          
            Listuser = Session["GridList"] as List<UserLogin>;
            if (ColumnName=="UserName")
            {
                if(Sort=="Asc")
                {
                    value = Listuser.OrderBy(u => u.UserName).ToList();
                }
                else
                {
                    value = Listuser.OrderByDescending(u => u.UserName).ToList();
                }
            }
            else if(ColumnName=="Designation")
            {
                if(Sort=="Asc")
                {
                    value = Listuser.OrderBy(u => u.Designation).ToList();

                }
                else
                {
                    value = Listuser.OrderByDescending(u => u.Designation).ToList();
                }

            }
            Session["GridList"] = value;
            value = value.Take(5).ToList();
            
            return PartialView("PartialViewSignUp", value);
        }
        public ActionResult Searching(string Usernamefilter, string Designationfilter)
        {
            Listuser = Session["GridList"] as List<UserLogin>;
           

                value = Listuser.Where(f => f.UserName.ToLower().Contains(Usernamefilter.ToLower()) && f.Designation.ToLower().Contains(Designationfilter.ToLower())).ToList();
          
            return PartialView("PartialViewSignUp", value);
        }
        public ActionResult Filtering(string UsernameSearch)
        {
            Listuser = Session["GridList"] as List<UserLogin>;

            if (UsernameSearch != null && UsernameSearch != "")
            {
                value = Listuser.Where(f => f.UserName.ToLower().Contains(UsernameSearch.ToLower()) || f.Designation.ToLower().Contains(UsernameSearch.ToLower())).ToList();
            }
            else
            {
                value = Listuser.Take(5).ToList();
            }

            return PartialView("PartialViewSignUp", value);
        }

    }
}

//var List = ds.Tables[0].AsEnumerable().Select(dataRow => new UserLogin
//{
//    UserLoginId = dataRow.Field<int>("UserLoginId"),
//    UserName = dataRow.Field<string>("UserName"),
//    Active = dataRow.Field<Convert.ToByte>("Active").ToString() == "True" ? 1 : 0
//}).ToList();