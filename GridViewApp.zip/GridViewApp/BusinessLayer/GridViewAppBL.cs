﻿using DataAccessLayer;
using System.Collections.Generic;
using System.Data;
using Utility;

namespace BusinessLayer
{
    
   public class GridViewAppBL
    {
        GridViewAppDL Dataobj = new GridViewAppDL();
        List<UserLogin> list = new List<UserLogin>();
        public bool InsertingBL(UserLogin ul)
        {
          
            bool Ins = Dataobj.AddUser(ul);
            return Ins;
        }
        public List<UserLogin> DesignationBL()
        {
            
          list = Dataobj.GetDesignation();
            return list;
        }
        public List<UserLogin> GetValuesBL(int id)
        {
            list = Dataobj.GetValues(id);
            return list;
        }
        public bool DeleteUserBL(int id)
        {
            bool del = Dataobj.DeleteUser(id);
            return del;
        }
        public DataSet LinqBL()
        {
            DataSet ds = Dataobj.LinqGetValues();
            return ds;
        }
    }
}
