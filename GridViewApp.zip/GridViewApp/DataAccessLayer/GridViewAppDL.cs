﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utility;
using System.Configuration;

namespace DataAccessLayer
{
    public class GridViewAppDL
    {
        Constant cons = new Constant();
            public bool AddUser(UserLogin ul)
            {
            string str= ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(str);
          
                    con.Open();
                    //string insert = "INSERT INTO GetUserValues(UserName,Active,Designation,DOB,Password) values (@Username,@Active,@Designation,@DOB,@Password)";
                    SqlCommand sqlcmd = new SqlCommand(cons.InsertUser, con);
                    sqlcmd.CommandType = CommandType.StoredProcedure;
                    sqlcmd.Parameters.AddWithValue("@UserLoginId", ul.UserLoginId);
                    sqlcmd.Parameters.AddWithValue("@UserName", ul.UserName);
                    sqlcmd.Parameters.AddWithValue("@Active", ul.Active);
                    sqlcmd.Parameters.AddWithValue("@Designation", ul.Designation);
                    sqlcmd.Parameters.AddWithValue("@DOB", ul.DOB);
                    sqlcmd.Parameters.AddWithValue("@Password", ul.Password);
                    sqlcmd.Parameters.AddWithValue("@Action", ul.Action);
                    sqlcmd.Parameters.Add("@isExist", SqlDbType.Bit);
                    sqlcmd.Parameters["@isExist"].Direction = ParameterDirection.Output;

                    int rowsadded = sqlcmd.ExecuteNonQuery();
                    ul.isExists = Convert.ToByte(sqlcmd.Parameters["@isExist"].Value.ToString() == "True" ? 1 : 0);
                    con.Close();
                    if (rowsadded == 0)
                        return false;
                    else
                        return true;

                
            }
            public List<UserLogin> GetDesignation()
            {
            string str = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(str);
            List<UserLogin> list = null;
                    SqlCommand sqlcmd = null;
                    con.Open();
                    sqlcmd = new SqlCommand(cons.GetDesignation, con);
                    sqlcmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter sda = new SqlDataAdapter(sqlcmd);
                    DataSet ds = new DataSet();
                    sda.Fill(ds);
                    UserLogin desg = null;
                    list = new List<UserLogin>();
                    DataTable dt = ds.Tables[0];
                    if (ds != null)
                    {
                        foreach (DataRow dr in dt.Rows)
                        {
                            desg = new UserLogin();
                            desg.Id = Convert.ToInt32(dr["Id"].ToString());
                            desg.Name = dr["Name"].ToString();
                            list.Add(desg);
                        }
                    }
                    return list;
                
            }

            public List<UserLogin> GetValues(int id)
            {

            string str = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(str);
            List<UserLogin> lstuser = null;
                    SqlCommand sqlcmd = null;
                    con.Open();
                    if (id == 0)
                        sqlcmd = new SqlCommand(cons.GetValues, con);
                    else
                    {
                        sqlcmd = new SqlCommand(cons.EditUser, con);
                        sqlcmd.Parameters.AddWithValue("@id", id);
                    }
                    sqlcmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter sda = new SqlDataAdapter(sqlcmd);
                    DataSet ds = new DataSet();
                    sda.Fill(ds);
                    UserLogin user = null;
                    lstuser = new List<UserLogin>();
                    DataTable dt = ds.Tables[0];
                    // int strcount = ds.Tables[1].Rows.Count;
                    if (ds != null)
                    {
                        foreach (DataRow r in dt.Rows)
                        {

                            user = new UserLogin();
                            user.UserLoginId = Convert.ToInt32(r["UserLoginId"].ToString());
                            user.UserName = r["UserName"].ToString();
                            user.Password = r["Password"].ToString();
                            user.Designation = r["Designation"].ToString();
                            user.DOB = Convert.ToDateTime(r["DOB"].ToString());
                            user.Active = Convert.ToByte(r["Active"].ToString() == "True" ? 1 : 0);
                            user.Id = Convert.ToInt32(r["DesgId"].ToString());


                            lstuser.Add(user);

                        }
                    }


                    return lstuser;
                
            }
            public DataSet GetValues1()
            {
            string str = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(str);

            con.Open();
                    SqlCommand sqlcmd = new SqlCommand(cons.GetValues, con);
                    sqlcmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter sda = new SqlDataAdapter(sqlcmd);
                    DataSet ds = new DataSet();
                    sda.Fill(ds);
                    return ds;


                

            }
            public bool DeleteUser(int id)
            {
            string str = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(str);
            con.Open();
                    SqlCommand sqlcmd = new SqlCommand(cons.DeleteUser, con);
                    sqlcmd.CommandType = CommandType.StoredProcedure;
                    sqlcmd.Parameters.AddWithValue("@id", id);
                    int rowsdelete = sqlcmd.ExecuteNonQuery();
                    if (rowsdelete > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                
            }
            public DataSet EditUser(int id)
            {
            string str = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(str);
            con.Open();
                    SqlCommand sqlcmd = new SqlCommand(cons.EditUser, con);
                    sqlcmd.CommandType = CommandType.StoredProcedure;
                    sqlcmd.Parameters.AddWithValue("@id", id);
                    SqlDataAdapter sda = new SqlDataAdapter(sqlcmd);
                    DataSet ds = new DataSet();
                    sda.Fill(ds);

                    //int rowsedited = sqlcmd.ExecuteNonQuery();
                    con.Close();
                    return ds;
                }

            
            public DataSet LinqGetValues()
            {

            string str = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(str);
            con.Open();
                    SqlCommand sqlcmd = new SqlCommand(cons.LinqGetValues, con);
                    sqlcmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter sda = new SqlDataAdapter(sqlcmd);
                    DataSet ds = new DataSet();
                    sda.Fill(ds);
                    con.Close();
                    return ds;
                }
            }

        }
    


