﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utility
{
    public class Constant
    {
        public string InsertUser = "AddUserValue";
        public string GetDesignation = "GetDesignation";
        public string GetValues = "GetUserValues1";
        public string DeleteUser = "DeleteValues";
        public string EditUser = "EditUser";
        public string LinqGetValues = "LinqGetList";

    }
}
