﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Utility
{
    public class UserLogin
    {
        public int UserLoginId { get; set; }
        public string UserName { get; set; }
        public Byte Active { get; set; }
        public int UserDetailId { get; set; }
        public string Designation { get; set; }
        public DateTime DOB { get; set; }
        public string Password { get; set; }
        public string Action { get; set; }
        public Byte isExists { get; set; }
        public int Id { get; set; }
        public string Name { get; set; }
        public int Count { get; set; }
       

    }
   

}