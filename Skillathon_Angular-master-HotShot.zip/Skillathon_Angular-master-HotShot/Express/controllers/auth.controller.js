const jwt = require('jsonwebtoken');
const User = require('../models/user.model');
const MESSAGE = require('../contstants/message.constant');

exports.register = (req, res, next) => {
    User.create({
        name: req.body.name,
        email: req.body.email,
        team: req.body.team,
        password: req.body.password,
        role: 'USER'
    }).then(user=>{
        res.json({
            user : user,
            token: jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRY }),
            expiresIn: process.env.JWT_EXPIRY,
            message: MESSAGE.REGISTERED,
            success: true
        });
    }).catch((error)=>{
        next(error);
    });
};

exports.login = (req, res, next) => {
    res.json({ token : jwt.sign({ id: req.user._id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRY }), user: req.user, expiresIn: process.env.JWT_EXPIRY });
}

exports.changePassword = (req, res, next) => {
    req.user.password = req.body.password;
    req.user.save().then(()=>{
        res.json({ message: MESSAGE.PASSWORD_CHANGED, success: true });
    }).catch((error)=>{
        next(error);
    });
}

exports.updateProfile = (req, res, next) => {
    req.user.name = req.body.name;
    req.user.email = req.body.email;
    req.user.team = req.body.team;
    req.user.save().then(()=>{
        res.json({
            message: MESSAGE.PROFILE_UPDATED,
            success: true,
            user: req.user
        });
    }).catch((error)=>{
        next(error);
    });
}