const router = require('express').Router();
const passport = require('passport');
const controller = require('../controllers/auth.controller');

router.post('/register', controller.register);
router.post('/login',passport.authenticate('local',{ failWithError: true }), controller.login);
router.post('/change-password',passport.authenticate('jwt', { session: false, failWithError: true }), controller.changePassword);
router.post('/update-profile',passport.authenticate('jwt', { session: false, failWithError: true }), controller.updateProfile);

module.exports = router;