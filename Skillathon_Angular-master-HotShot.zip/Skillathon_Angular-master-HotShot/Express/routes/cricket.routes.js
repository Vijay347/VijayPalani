const router = require('express').Router();
const controller = require('../controllers/cricket.controller');

router.get('/dashboard', controller.getDashboard);
router.get('/matches', controller.getMatches);
router.get('/most-runs', controller.getMostRuns);
router.get('/highest-scores', controller.getHighestScores);
router.get('/batting-average', controller.getBatttingAverage);
router.get('/batsman-ranking', controller.getBatsmanRanking);
router.get('/most-centuries', controller.getMostCenturies);
router.get('/most-fifties', controller.getMostFifties);
router.get('/most-sixes', controller.getMostSixes);
router.get('/most-fours', controller.getMostFours);
router.get('/match-details/:id', controller.getMatchDetails);
router.get('/team-comparison', controller.getTeamComparison);
router.get('/scores/:matchId', controller.getScores);
router.get('/score/:matchId/:id', controller.getScore);
router.post('/score/:matchId/:id', controller.updateScore);
router.get('/teams', controller.getTeams);
router.get('/favourite-teams', controller.getFavouriteTeams);
router.get('/players/:season/:team', controller.getPlayers);

module.exports = router;