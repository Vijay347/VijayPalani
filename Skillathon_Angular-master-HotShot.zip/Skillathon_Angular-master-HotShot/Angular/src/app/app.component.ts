import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';
import { AuthService } from '@services/auth.service';
import { LoaderService } from '@services/loader.service';
import { SeoService } from '@services/seo.service';
import { AlertService } from '@services/alert.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { RegisterComponent } from '@components/register/register.component';
import { LoginComponent } from '@components/login/login.component';
import { ChangePasswordComponent } from '@components/change-password/change-password.component';
import { UpdateProfileComponent } from '@components/update-profile/update-profile.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  title:string;
  subTitle:string;
  user: any;
  loggedIn: boolean = false;
  loading: boolean = false;
  dt: Date = new Date();
  module:string;
  $timeout;

  constructor(private router: Router, private auth: AuthService, private cd: ChangeDetectorRef, private loader: LoaderService, private seoService:SeoService, private alertService: AlertService, private modalService: NgbModal) {

  }

  ngOnInit() {
    this.router.events.subscribe((event)=>{
      if(event instanceof NavigationStart){
        this.seoService.setTitle(null);
      }
    });
    if(this.auth.loggedIn()) {
      this.loggedIn = true;
      this.user = this.auth.getUser();
      this.setExpiry();
    }
    this.auth.loginHook().subscribe(user => {
      this.loggedIn = true;
      this.user = user;
      this.clearExpiry();
      this.setExpiry();
    });
    this.auth.logoutHook().subscribe(() => {
      this.loggedIn = false;
      this.user = {};
      this.clearExpiry();
    });
    this.loader.getState().subscribe(status => {
      this.loading = status;
      this.cd.detectChanges();
    });
    this.seoService.getTitle().subscribe((seo)=>{
      this.title = seo.title;
      this.subTitle = seo.subTitle;
    });
  }

  logout(){
    this.auth.logout();
  }

  setExpiry(){
    this.$timeout = setTimeout(()=>{
      this.alertService.show('Your session has expired. Please log in.',false).result.then(()=>{
        this.auth.logout();
        this.router.navigate(['/auth/login']);
      },() => {
        this.auth.logout();
        this.router.navigate(['/auth/login']);
      });
    },this.auth.getExpiry());
  }

  clearExpiry(){
    if(this.$timeout){
      clearTimeout(this.$timeout);
    }
  }

  register(){
    this.modalService.open(RegisterComponent,{
      centered: true,
      backdrop: 'static'
    });
  }

  login(){
    this.modalService.open(LoginComponent,{
      centered: true,
      backdrop: 'static'
    });
  }

  changePassword(){
    this.modalService.open(ChangePasswordComponent,{
      centered: true,
      backdrop: 'static'
    });
  }

  updateProfile(){
    this.modalService.open(UpdateProfileComponent,{
      centered: true,
      backdrop: 'static'
    });
  }

}