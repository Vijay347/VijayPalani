import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from '@components/dashboard/dashboard.component';
import { MostRunsComponent } from '@components/most-runs/most-runs.component';
import { BattingAverageComponent } from '@components/batting-average/batting-average.component';
import { LayoutComponent } from '@components/layout/layout.component';
import { HighScoresComponent } from '@components/high-scores/high-scores.component';
import { MostCenturiesComponent } from '@components/most-centuries/most-centuries.component';
import { MostFiftiesComponent } from '@components/most-fifties/most-fifties.component';
import { MostFoursComponent } from '@components/most-fours/most-fours.component';
import { MostSixesComponent } from '@components/most-sixes/most-sixes.component';
import { BatsmanRankingComponent } from '@components/batsman-ranking/batsman-ranking.component';
import { MatchesComponent } from '@components/matches/matches.component';
import { MatchDetailsComponent } from '@components/match-details/match-details.component';
import { TeamComparisonComponent } from '@components/team-comparison/team-comparison.component';
import { ManageScoresComponent } from '@components/manage-scores/manage-scores.component';
import { ManageScoreComponent } from '@components/manage-score/manage-score.component';
import { ScoreComponent } from '@components/score/score.component';
import { ManageTeamsComponent } from '@components/manage-teams/manage-teams.component';
import { ManageTeamComponent } from '@components/manage-team/manage-team.component';
import { TeamComponent } from '@components/team/team.component';

const routes: Routes = [
  { 
    path: '', component: LayoutComponent, children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard', component: DashboardComponent },
      { path: 'matches', component: MatchesComponent },
      { path: 'match-details/:id', component: MatchDetailsComponent },
      { path: 'most-runs', component: MostRunsComponent },
      { path: 'high-scores', component: HighScoresComponent },
      { path: 'batting-average', component: BattingAverageComponent },
      { path: 'most-centuries', component: MostCenturiesComponent },
      { path: 'most-fifties', component: MostFiftiesComponent },
      { path: 'most-sixes', component: MostSixesComponent },
      { path: 'most-fours', component: MostFoursComponent },
      { path: 'team-comparison', component: TeamComparisonComponent },
      { path: 'batsman-ranking', component: BatsmanRankingComponent },
      { path: 'manage-scores', component: ManageScoresComponent },
      { path: 'manage-scores/:id', component: ManageScoreComponent },
      { path: 'manage-scores/:matchId/:id', component: ScoreComponent },
      { path: 'manage-teams', component: ManageTeamsComponent },
      { path: 'manage-teams/:season/:team', component: ManageTeamComponent },
      { path: 'manage-teams/:season/:team/:player', component: TeamComponent }
    ] 
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    scrollPositionRestoration: 'top',
    anchorScrolling: 'enabled'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
