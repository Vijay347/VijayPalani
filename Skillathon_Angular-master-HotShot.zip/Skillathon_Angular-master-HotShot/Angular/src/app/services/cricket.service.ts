import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Dashboard, MostRuns, BattingAverages, HighScores, BatsmanRankings, MostCenturies, MostFifties, MostSixes, Matches, Teams, TeamComparison } from '@interfaces/cricket.interface';

@Injectable({
  providedIn: 'root'
})
export class CricketService {

  private API_PATH:string = '/api/cricket';

  constructor(private http: HttpClient) { }

  getDashboard(params: any) : Observable<Dashboard>{
    return this.http.get<Dashboard>(`${this.API_PATH}/dashboard`,{ params: params });
  }

  getMatches(queryParams) : Observable<Matches>{
    return this.http.get<Matches>(`${this.API_PATH}/matches`,{ params: queryParams });
  }

  getMatchDetails(id:number) : Observable<TeamComparison>{
    return this.http.get<TeamComparison>(`${this.API_PATH}/match-details/${id}`);
  }

  getMostRuns(params: any) : Observable<MostRuns>{
    return this.http.get<MostRuns>(`${this.API_PATH}/most-runs`,{ params: params });
  }

  getBattingAverage(queryParams) : Observable<BattingAverages>{
    return this.http.get<BattingAverages>(`${this.API_PATH}/batting-average`,{ params: queryParams });
  }

  getBatsmanRanking(queryParams) : Observable<BatsmanRankings>{
    return this.http.get<BatsmanRankings>(`${this.API_PATH}/batsman-ranking`,{ params: queryParams });
  }

  getHighScores(queryParams) : Observable<HighScores>{
    return this.http.get<HighScores>(`${this.API_PATH}/highest-scores`,{ params: queryParams });
  }

  getMostCenturies(queryParams) : Observable<MostCenturies>{
    return this.http.get<MostCenturies>(`${this.API_PATH}/most-centuries`,{ params: queryParams });
  }

  getMostFifties(queryParams) : Observable<MostFifties>{
    return this.http.get<MostFifties>(`${this.API_PATH}/most-fifties`,{ params: queryParams });
  }

  getMostSixes(queryParams) : Observable<MostSixes>{
    return this.http.get<MostSixes>(`${this.API_PATH}/most-sixes`,{ params: queryParams });
  }

  getMostFours(queryParams) : Observable<any>{
    return this.http.get<any>(`${this.API_PATH}/most-fours`,{ params: queryParams });
  }
  
  getTeamComparison(queryParams) : Observable<TeamComparison>{
    return this.http.get<TeamComparison>(`${this.API_PATH}/team-comparison`,{ params: queryParams });
  }

  getScores(id:number) : Observable<any>{
    return this.http.get<any>(`${this.API_PATH}/scores/${id}`);
  }

  getScore(params:any) : Observable<any>{
    return this.http.get<any>(`${this.API_PATH}/score/${params.matchId}/${params.id}`);
  }

  updateScore(params:any,data:any) : Observable<any>{
    return this.http.post<any>(`${this.API_PATH}/score/${params.matchId}/${params.id}`,data);
  }

  getTeams() : Observable<Teams>{
    return this.http.get<Teams>(`${this.API_PATH}/teams`);
  }

  getFavouriteTeams() : Observable<string[]>{
    return this.http.get<string[]>(`${this.API_PATH}/favourite-teams`);
  }

  getPlayers(season:number, team:string) : Observable<any>{
    return this.http.get<any>(`${this.API_PATH}/players/${season}/${team}`);
  }

  getPlayer(season:number, team:string) : Observable<any>{
    return this.http.get<any>(`${this.API_PATH}/players/${season}/${team}`);
  }

  savePlayer(season:number, team:string) : Observable<any>{
    return this.http.get<any>(`${this.API_PATH}/players/${season}/${team}`);
  }

}
