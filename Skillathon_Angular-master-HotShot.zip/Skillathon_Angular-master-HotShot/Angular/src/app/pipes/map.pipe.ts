import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'map'
})
export class MapPipe implements PipeTransform {

  transform(values: any[], maps: any = {}): any {
    return values.map((value)=>{
      const mapValue = {};
      Object.keys(maps).forEach((map)=>{
        mapValue[map] = value[maps[map]];
      });
      return mapValue;
    });
  }

}
