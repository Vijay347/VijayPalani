import { TotalPipe } from './total.pipe';

describe('TotalPipe', () => {
  it('create an instance', () => {
    const pipe = new TotalPipe();
    expect(pipe).toBeTruthy();
  });
});
