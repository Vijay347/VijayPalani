import { MapPipe } from './map.pipe';

describe('MapPipe', () => {
  it('create an instance', () => {
    const pipe = new MapPipe();
    expect(pipe).toBeTruthy();
  });
});
