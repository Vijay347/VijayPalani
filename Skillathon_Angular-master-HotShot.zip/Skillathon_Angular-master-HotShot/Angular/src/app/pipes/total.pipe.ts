import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'total'
})
export class TotalPipe implements PipeTransform {

  transform(values: any[], prop: string): any {
    return values.map((value)=>{
      return value[prop];
    }).reduce((a,b)=>{
      return a+b;
    });
  }

}
