import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(values: any[], args: any = {}, exact = false): any[] {
    return values.filter((value)=>{
      if(exact){
        return Object.keys(args).every((key)=>{
          return !args[key] || (args[key] && value[key] == args[key]);
        });
      }else{
        return Object.keys(args).some((key)=>{
          return !args[key] || (args[key] && value[key] == args[key]);
        });
      }
    });
  }

}
