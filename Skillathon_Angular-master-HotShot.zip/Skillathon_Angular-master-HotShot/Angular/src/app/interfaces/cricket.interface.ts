
//Season
export interface Season {
    season: number;
}

//Dashboard
export interface DashboardMostRuns {
    runs: number;
    team: string;
    batsman: string;
}
export interface DashboardBatsmanRanking {
    batsman: string;
    team: string;
    rank: number;
}
export interface DashboardBattingAverage {
    batsman: string;
    team: string;
    average: number;
}
export interface DashboardHighestScore {
    runs: number;
    team: string;
    batsman: string;
}
export interface DashboardMostCentury {
    centuries: number;
    batsman: string;
    team: string;
}
export interface DashboardMostFifty {
    fifties: number;
    batsman: string;
    team: string;
}
export interface Dashboard {
    mostRuns: DashboardMostRuns[];
    highestScores: DashboardHighestScore[];
    battingAverage: DashboardBattingAverage[];
    batsmanRanking: DashboardBatsmanRanking[];
    mostCenturies: DashboardMostCentury[];
    mostFifties: DashboardMostFifty[];
    seasons: number[];
    season: number;
}
//MostRuns
export interface MostRuns {
    mostRuns: MostRun[];
    seasons: number[];
    season: number;
    teams: string[];
}
export interface MostRun {
    matches: number;
    runs: number;
    season: number;
    team: string;
    batsman: string;
    average: number;
}
//HighScores
export interface HighScores {
    highScores: HighScore[];
    seasons: number[];
    teams: string[];
    season: number;
}
export interface HighScore {
    runs: number;
    season: number;
    team: string;
    batsman: string;
}
//BattingAverages
export interface BattingAverages {
    battingAverages: BattingAverage[];
    seasons: number[];
    teams: any[];
    season: number;
}
export interface BattingAverage {
    matches: number;
    runs: number;
    season: number;
    team: string;
    batsman: string;
    average: number;
}
//BatsmanRankings
export interface BatsmanRankings {
    batsmanRankings: BatsmanRanking[];
    seasons: number[];
    teams: string[];
    season: number;
}
export interface BatsmanRanking {
    season: number;
    team: string;
    batsman: string;
    matches: number;
    runs: number;
    average: number;
    rank: number;
}
//MostCenturies
export interface MostCenturies {
    mostCenturies: MostCentury[];
    seasons: number[];
    teams: string[];
    season: number;
}
export interface MostCentury {
    matches: number;
    centuries: number;
    runs: number;
    season: number;
    team: string;
    batsman: string;
    average: number;
}
//MostFifties
export interface MostFifties {
    mostFifties: MostFifty[];
    seasons: number[];
    teams: string[];
    season: number;
}
export interface MostFifty {
    matches: number;
    fifties: number;
    runs: number;
    season: number;
    team: string;
    batsman: string;
    average: number;
}
//MostSixes
export interface MostSixes {
    mostSixes: MostSix[];
    seasons: number[];
    teams: string[];
    season: number;
}
export interface MostSix {
    matches: number;
    sixes: number;
    runs: number;
    season: number;
    team: string;
    batsman: string;
    average: number;
}
//Matches
export interface Matches {
    matches: Match[];
    seasons: number[];
    teams: string[];
    season: number;
}
export interface Match {
    _id: string;
    id: number;
    season: number;
    city: string;
    date: string;
    team1: string;
    team2: string;
    toss_winner: string;
    toss_decision: string;
    result: string;
    dl_applied: number;
    winner: string;
    win_by_runs: number;
    win_by_wickets: number;
    player_of_match: string;
    venue: string;
    umpire1: string;
    umpire2: string;
    umpire3: string;
}
//Teams
export interface Teams {
    teams: Team[];
    seasons: number[];
}
export interface Team {
    name: string;
    season: number;
}
//TeamComparison
export interface TeamComparison {
    matches: Match[];
    battings: Batting[];
    bowlings: Bowling[];
}
export interface Batting {
    balls: number;
    fours: number;
    sixes: number;
    extras: number;
    season: number;
    batsman: string;
    team: string;
    matchId: number;
    totalRuns: number;
    runs: number;
}
export interface Bowling {
    maidens: number;
    wickets: number;
    dots: number;
    extras: number;
    season: number;
    bowler: string;
    team: string;
    matchId: number;
    overs: number;
    runs: number;
}