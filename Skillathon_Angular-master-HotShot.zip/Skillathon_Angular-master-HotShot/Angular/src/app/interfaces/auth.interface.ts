import { Status } from './status.interface';
//User
export interface User {
    _id: string;
    name: string;
    email: string;
    password: string;
    role: string;
    createdAt: string;
    updatedAt: string;
    __v: number;
}
//JWT
export interface Jwt {
    token:     string;
    expiresIn: number;
}
//Register
export interface Register {
    name: string;
    mobile: string;
    email: string;
    password: string;
    confirmPassword: string;
}
//TokenResponse
export interface TokenResponse extends Jwt, Status {
    user: User
}
//Login
export interface Login {
    name: string;
    password: string;
}
//ChangePassword
export interface ChangePassword {
    password: string;
    confirmPassword: string;
}