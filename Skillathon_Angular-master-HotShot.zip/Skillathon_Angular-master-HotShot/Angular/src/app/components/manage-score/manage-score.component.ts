import { Component, OnInit } from '@angular/core';
import { CricketService } from '@services/cricket.service';
import { SeoService } from '@services/seo.service';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { listAnimation } from '@animations/list-animation';

@Component({
  selector: 'app-manage-score',
  templateUrl: './manage-score.component.html',
  styleUrls: ['./manage-score.component.scss'],
  animations: [
    listAnimation
  ]
})
export class ManageScoreComponent implements OnInit {

   scores: any[] = [];
   overs: number[] = Array.from(Array(20).keys()).map(v=> v+1 );
   innings: string[] = [];
   form:FormGroup;
 
   constructor(private seoService:SeoService, private cricketService:CricketService, private route:ActivatedRoute, private fb:FormBuilder) {
  
   }
 
   ngOnInit() {
     this.setForm();
     this.loadData(this.route.snapshot.params.id);
   }

   setForm(){
    this.form = this.fb.group({
      innings: null,
      over: 1
    });
  }
 
   loadData(matchId){
     this.cricketService.getScores(matchId).subscribe((response)=>{
       this.scores = response;
       this.seoService.setTitle('Manage Score',`${ response[0].batting_team } vs ${ response[0].bowling_team }`);
       this.innings.push(response[0].batting_team);
       this.innings.push(response[0].bowling_team);
       this.innings = [...new Set(this.innings)];
       this.form.get('innings').setValue(response[0].batting_team);
     });
   }
 
   onPageChange(){
     window.scroll(0,0);
   }
 
}
