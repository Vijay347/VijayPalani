import { Component, OnInit } from '@angular/core';
import { CricketService } from '@services/cricket.service';
import { SeoService } from '@services/seo.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { listAnimation } from '@animations/list-animation';

@Component({
  selector: 'app-manage-teams',
  templateUrl: './manage-teams.component.html',
  styleUrls: ['./manage-teams.component.scss'],
  animations: [
    listAnimation
  ]
})
export class ManageTeamsComponent implements OnInit {

  seasons: any[] = [];
  teams: any[] = [];
  form:FormGroup;

  constructor(private seoService:SeoService, private cricketService:CricketService, private route:ActivatedRoute, private router:Router, private fb:FormBuilder) {

   }

  ngOnInit() {
    this.setForm();
    this.loadData();
  }

  setForm(){
    this.form = this.fb.group({
      season: null
    });
    this.form.patchValue(this.route.snapshot.queryParams);
  }

  loadData(){
    this.cricketService.getTeams().subscribe((response)=>{
      this.seoService.setTitle('Manage Teams');
      this.seasons = response.seasons;
      this.teams = response.teams;
      this.form.get('season').setValue(this.seasons[0]);
    });
  }

}
