import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MostSixesComponent } from '@components/most-sixes/most-sixes.component';

describe('MostSixesComponent', () => {
  let component: MostSixesComponent;
  let fixture: ComponentFixture<MostSixesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MostSixesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MostSixesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
