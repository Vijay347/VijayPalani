import { Component, OnInit } from '@angular/core';
import { CricketService } from '@services/cricket.service';
import { SeoService } from '@services/seo.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { listAnimation } from '@animations/list-animation';
import { Match } from '@interfaces/cricket.interface';

@Component({
  selector: 'app-matches',
  templateUrl: './matches.component.html',
  styleUrls: ['./matches.component.scss'],
  animations: [
    listAnimation
  ]
})
export class MatchesComponent implements OnInit {

  matches: Match[] = [];
  seasons: number[] = [];
  teams: string[] = [];
  form:FormGroup;
  page:number = 1;

  constructor(private seoService:SeoService, private cricketService:CricketService, private route:ActivatedRoute, private router:Router, private fb:FormBuilder) {

   }

  ngOnInit() {
    this.setForm();
    this.paramsChange();
  }

  setForm(){
    this.form = this.fb.group({
      team: null,
      season: null
    });
    this.form.patchValue(this.route.snapshot.queryParams);
  }

  loadData(queryParams){
    this.cricketService.getMatches(queryParams).subscribe((response)=>{
      this.seoService.setTitle('Matches',response.season.toString());
      this.matches = response.matches;
      this.seasons = response.seasons;
      this.teams = response.teams;
      this.form.get('season').setValue(response.season);
    });
  }

  paramsChange():void{
    this.route.queryParams.subscribe((params)=>{
      this.loadData(params);
    });
  }

  changeSeason(){
    this.matches = [];
    this.form.get('team').setValue(null);
    this.router.navigate(['/matches'], { queryParams:  { season : this.form.get('season').value } });
  }

  onPageChange(){
    window.scroll(0,0);
  }

}
