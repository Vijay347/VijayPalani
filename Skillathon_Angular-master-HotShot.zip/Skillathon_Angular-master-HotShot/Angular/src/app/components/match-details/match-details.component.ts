import { Component, OnInit } from '@angular/core';
import { CricketService } from '@services/cricket.service';
import { SeoService } from '@services/seo.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { listAnimation } from '@animations/list-animation';
import { Match, Batting, Bowling } from '@interfaces/cricket.interface';

@Component({
  selector: 'app-match-details',
  templateUrl: './match-details.component.html',
  styleUrls: ['./match-details.component.scss'],
  animations: [
    listAnimation
  ]
})
export class MatchDetailsComponent implements OnInit {

  matches: Match[] = [];
  battings: Batting[] = [];
  bowlings: Bowling[] = [];
  form:FormGroup;

  constructor(private seoService:SeoService, private cricketService:CricketService, private route:ActivatedRoute, private router:Router, private fb:FormBuilder) {

  }

  ngOnInit() {
    this.loadData();
  }

  loadData(){
    this.cricketService.getMatchDetails(this.route.snapshot.params.id).subscribe((response)=>{
      this.matches = response.matches;
      this.battings = response.battings;
      this.bowlings = response.bowlings;
      if(response.matches.length){
        this.seoService.setTitle(`${ response.matches[0].team1 } Vs ${ response.matches[0].team2 }`,response.matches[0].season.toString());
      }
    });
  }

  firstInnings(match){
    return match.toss_decision == 'bat' ? match.toss_winner : ( match.toss_winner == match.team1 ? match.team2 : match.team1 );
  }

  secondInnings(match){
    return this.firstInnings(match) == match.team1 ? match.team2 : match.team1;
  }

}
