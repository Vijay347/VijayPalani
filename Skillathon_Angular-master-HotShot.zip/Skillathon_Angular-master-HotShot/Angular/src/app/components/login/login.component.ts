import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '@services/auth.service';
import { CustomValidator } from '@services/custom-validator.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  form: FormGroup;
  submitted: boolean = false;

  constructor(private fb: FormBuilder, private router:Router, private auth:AuthService, public activeModal: NgbActiveModal) { }

  ngOnInit() {
    this.auth.logout();
    this.setForm();
  }

  private setForm(): void {
    this.form = this.fb.group({
      email : [null, [Validators.required, CustomValidator.email]],
      password : [null, [Validators.required, Validators.minLength(8)]]
    });
  }

  hasError(control:string, validation:string) : boolean{
    return this.form.get(control).hasError(validation) && (this.form.get(control).touched || this.submitted);
  }

  onSubmit(){
    this.submitted = true;
    if(this.form.valid){
      this.auth.login(this.form.value).subscribe((response)=>{
        this.activeModal.close();
      });
    }
  }
}
