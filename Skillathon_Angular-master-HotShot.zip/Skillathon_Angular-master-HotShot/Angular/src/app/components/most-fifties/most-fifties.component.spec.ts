import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MostFiftiesComponent } from '@components/most-fifties/most-fifties.component';

describe('MostFiftiesComponent', () => {
  let component: MostFiftiesComponent;
  let fixture: ComponentFixture<MostFiftiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MostFiftiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MostFiftiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
