import { Component, OnInit } from '@angular/core';
import { CricketService } from '@services/cricket.service';
import { SeoService } from '@services/seo.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { listAnimation } from '@animations/list-animation';
import { MostFifty } from '@interfaces/cricket.interface';

@Component({
  selector: 'app-most-fifties',
  templateUrl: './most-fifties.component.html',
  styleUrls: ['./most-fifties.component.scss'],
  animations: [
    listAnimation
  ]
})
export class MostFiftiesComponent implements OnInit {

  mostFifties: MostFifty[] = [];
  seasons: number[] = [];
  teams: string[] = [];
  viewTypes: string[] = ['Table','Chart'];
  form:FormGroup;
  
  showXAxis = true;
  showYAxis = true;
  gradient = false;
  showYAxisLabel = true;
  xAxisLabel = 'Batsman';
  yAxisLabel = 'Fifties';
  showDataLabel = true;
  barPadding = 8;
  colorScheme = {
    domain: ['#777', '#fca402', '#35a7e0', '#4c49d8', '#fa1000', '#2cb713']
  };

  constructor(private seoService:SeoService, private cricketService:CricketService, private route:ActivatedRoute, private router:Router, private fb:FormBuilder) {

   }

  ngOnInit() {
    this.setForm();
    this.paramsChange();
  }

  setForm(){
    this.form = this.fb.group({
      team: null,
      season: null,
      viewType: 'Table'
    });
    this.form.patchValue(this.route.snapshot.queryParams);
  }

  loadData(queryParams){
    this.cricketService.getMostFifties(queryParams).subscribe((response)=>{
      this.seoService.setTitle('Most Fifties',response.season.toString());
      this.mostFifties = response.mostFifties;
      this.seasons = response.seasons;
      this.teams = response.teams;
      this.form.get('season').setValue(response.season);
    });
  }

  paramsChange():void{
    this.route.queryParams.subscribe((params)=>{
      this.loadData(params);
    });
  }

  changeSeason(){
    this.mostFifties= [];
    this.form.get('team').setValue(null);
    this.router.navigate(['/most-fifties'], { queryParams:  { season : this.form.get('season').value } });
  }

  axisFormat(val){
    if (val % 1 === 0) {
      return val.toLocaleString();
    } else {
      return '';
    }
  }

}
