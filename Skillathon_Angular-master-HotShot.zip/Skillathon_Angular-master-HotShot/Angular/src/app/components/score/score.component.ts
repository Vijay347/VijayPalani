import { Component, OnInit } from '@angular/core';
import { CricketService } from '@services/cricket.service';
import { SeoService } from '@services/seo.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { listAnimation } from '@animations/list-animation';
import { AlertService } from '@services/alert.service';

@Component({
  selector: 'app-score',
  templateUrl: './score.component.html',
  styleUrls: ['./score.component.scss'],
  animations: [
    listAnimation
  ]
})
export class ScoreComponent implements OnInit {

   form:FormGroup;
   submitted:boolean = false;
   innings: number[] = [1,2];
   teams: string[] = [];
   players: string[] = [];
   overs: number[] = Array.from(Array(20).keys()).map(v=> v+1 );
   balls: number[] = Array.from(Array(6).keys()).map(v=> v+1 );
   dismissalKinds: string[] = ['bowled','caught','run out','lbw','caught and bowled','stumped'];
 
   constructor(private seoService:SeoService, private cricketService:CricketService, private route:ActivatedRoute, private fb:FormBuilder, private alertService: AlertService, private router:Router) {
  
   }
 
   ngOnInit() {
     this.setForm();
     this.loadData(this.route.snapshot.params);
   }

   setForm(){
    this.form = this.fb.group({
      inning: { value : null, disabled : true },
      batting_team: { value : null, disabled : true },
      bowling_team: { value : null, disabled : true },
      over: { value : null, disabled : true },
      ball: { value : null, disabled : true },
      batsman: [null,Validators.required],
      non_striker: [null,Validators.required],
      bowler: [null,Validators.required],
      is_super_over: null,
      wide_runs: [0,Validators.required],
      bye_runs: [0,Validators.required],
      legbye_runs: [0,Validators.required],
      noball_runs: [0,Validators.required],
      penalty_runs: [0,Validators.required],
      batsman_runs: [0,Validators.required],
      extra_runs: [0,Validators.required],
      total_runs: [0,Validators.required],
      player_dismissed: null,
      dismissal_kind: null,
      fielder: null
    });
  }
 
   loadData(params){
     this.cricketService.getScore(params).subscribe((response)=>{
       this.seoService.setTitle('Manage Score',`${ response.delivery.batting_team } vs ${ response.delivery.bowling_team }`);
        this.form.patchValue(response.delivery,{ emitEvent : false });
        this.teams.push(response.delivery.batting_team);
        this.teams.push(response.delivery.bowling_team);
        this.teams = [...new Set(this.teams)];
        this.players = response.players;
     });
   }

   changeBattingTeam(){
    this.form.get('bowling_team').setValue(this.teams.find(team=>team!=this.form.get('batting_team').value));
    this.form.get('batsman').setValue(null);
    this.form.get('non_striker').setValue(null);
    this.form.get('bowler').setValue(null);
    this.form.get('player_dismissed').setValue(null);
    this.form.get('fielder').setValue(null);
   }

   changeBowlingTeam(){
    this.form.get('batting_team').setValue(this.teams.find(team=>team!=this.form.get('bowling_team').value));
    this.form.get('batsman').setValue(null);
    this.form.get('non_striker').setValue(null);
    this.form.get('bowler').setValue(null);
    this.form.get('player_dismissed').setValue(null);
    this.form.get('fielder').setValue(null);
   }

   hasError(control:string, validation:string) : boolean{
    return this.form.get(control).hasError(validation) && (this.form.get(control).touched || this.submitted);
  }

  onSubmit(){
    this.submitted = true;
    if(this.form.valid){
      this.cricketService.updateScore(this.route.snapshot.params, this.form.value).subscribe((response)=>{
        this.router.navigate([response.redirect]);
        this.alertService.show(response.message, response.success);
      });
    }
  }
 
}
