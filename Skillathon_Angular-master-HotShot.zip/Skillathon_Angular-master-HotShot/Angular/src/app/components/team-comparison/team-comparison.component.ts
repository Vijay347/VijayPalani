import { Component, OnInit } from '@angular/core';
import { CricketService } from '@services/cricket.service';
import { SeoService } from '@services/seo.service';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { listAnimation } from '@animations/list-animation';
import { AlertService } from '@services/alert.service';
import { Match, Batting, Bowling, Team } from '@interfaces/cricket.interface';

@Component({
  selector: 'app-team-comparison',
  templateUrl: './team-comparison.component.html',
  styleUrls: ['./team-comparison.component.scss'],
  animations: [
    listAnimation
  ]
})
export class TeamComparisonComponent implements OnInit {

  teams: Team[] = [];
  seasons: number[] = [];
  matches: Match[] = [];
  battings: Batting[] = [];
  bowlings: Bowling[] = [];
  form:FormGroup;

  constructor(private seoService:SeoService, private cricketService:CricketService, private route:ActivatedRoute, private alert:AlertService, private fb:FormBuilder) {

  }

  ngOnInit() {
    this.setForm();
    this.loadData();
    this.seoService.setTitle('Team Comparison');
  }

  setForm(){
    this.form = this.fb.group({
      season: [2019,Validators.required],
      team1: [null,Validators.required],
      team2: [null,Validators.required]
    });
    this.form.patchValue(this.route.snapshot.queryParams);
  }

  loadData(){
    this.cricketService.getTeams().subscribe((response)=>{
      this.teams = response.teams;
      this.seasons = response.seasons;
    });
  }

  teamChange(){
    if(this.form.get('team1').valid && this.form.get('team2').valid){
      if(this.form.get('team1').value  == this.form.get('team2').value){
        this.alert.show('You are not allowed to comapare same team.',false);
      }else{
        this.getTeamComparison(this.form.value);
      }
    }else{
      this.matches = [];
      this.battings = [];
      this.bowlings = [];
      this.seoService.setTitle('Team Comparison');
    }
  }

  changeSeason(){
    this.form.get('team1').setValue(null);
    this.form.get('team2').setValue(null);
    this.matches = [];
    this.battings = [];
    this.bowlings = [];
  }

  getTeamComparison(params){
    this.cricketService.getTeamComparison(params).subscribe((response)=>{
      this.matches = response.matches;
      this.battings = response.battings;
      this.bowlings = response.bowlings;
      if(this.matches.length){
        this.seoService.setTitle('Team Comparison',`${this.matches[0].team1} Vs ${this.matches[0].team2}`);
      }
    });
  }

  firstInnings(match){
    return match.toss_decision == 'bat' ? match.toss_winner : ( match.toss_winner == match.team1 ? match.team2 : match.team1 );
  }

  secondInnings(match){
    return this.firstInnings(match) == match.team1 ? match.team2 : match.team1;
  }

}
