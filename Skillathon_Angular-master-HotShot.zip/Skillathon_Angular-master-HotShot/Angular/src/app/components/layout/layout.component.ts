import { Component, OnInit } from '@angular/core';
import { AuthService } from '@services/auth.service';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss']
})
export class LayoutComponent implements OnInit {

  user: any;
  loggedIn: boolean = false;

  constructor(private auth: AuthService) { }

  ngOnInit() {
    if(this.auth.loggedIn()) {
      this.loggedIn = true;
      this.user = this.auth.getUser();
    }
    this.auth.loginHook().subscribe(user => {
      this.loggedIn = true;
      this.user = user;
    });
    this.auth.logoutHook().subscribe(() => {
      this.loggedIn = false;
      this.user = {};
    });
  }

  favouriteTeam(){
    return `url('/assets/images/favourite-team-background/${this.user.team.toLowerCase()}.svg')`;
  }

}
