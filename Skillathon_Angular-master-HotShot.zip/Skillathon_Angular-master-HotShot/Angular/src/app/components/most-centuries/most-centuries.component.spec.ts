import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MostCenturiesComponent } from '@components/most-centuries/most-centuries.component';

describe('MostCenturiesComponent', () => {
  let component: MostCenturiesComponent;
  let fixture: ComponentFixture<MostCenturiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MostCenturiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MostCenturiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
