import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageScoresComponent } from './manage-scores.component';

describe('ManageScoresComponent', () => {
  let component: ManageScoresComponent;
  let fixture: ComponentFixture<ManageScoresComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageScoresComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageScoresComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
