import { Component, OnInit } from '@angular/core';
import { CricketService } from '@services/cricket.service';
import { SeoService } from '@services/seo.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { listAnimation } from '@animations/list-animation';

@Component({
  selector: 'app-manage-scores',
  templateUrl: './manage-scores.component.html',
  styleUrls: ['./manage-scores.component.scss'],
  animations: [
    listAnimation
  ]
})
export class ManageScoresComponent implements OnInit {

   matches: any[] = [];
   seasons: any[] = [];
   teams: any[] = [];
   form:FormGroup;
   page:number = 1;
 
   constructor(private seoService:SeoService, private cricketService:CricketService, private route:ActivatedRoute, private router:Router, private fb:FormBuilder) {
    }
 
   ngOnInit() {
     this.setForm();
     this.queryParamsChange();
   }
 
   setForm(){
     this.form = this.fb.group({
       team: null,
       season: null
     });
   }
 
   loadData(queryParams){
     this.matches = [];
     this.cricketService.getMatches(queryParams).subscribe((response)=>{
       this.matches = response.matches;
       this.matches.forEach((team)=>{
         this.teams.push(team.team1);
         this.teams.push(team.team2);
       });
       this.teams = [...new Set(this.teams)];
       this.seasons = response.seasons;
       this.form.get('season').setValue(this.matches[0].season);
       this.seoService.setTitle('Manage Score','(Matches)');
     });
   }
 
   queryParamsChange():void{
     this.route.queryParams.subscribe((queryParams)=>{
       this.loadData(queryParams);
     });
   }
 
   changeSeason(){
     this.router.navigate(['/manage-scores'], { queryParams: { season : this.form.get('season').value }, queryParamsHandling: 'merge' });
   }
 
   onPageChange(){
     window.scroll(0,0);
   }
 
}
