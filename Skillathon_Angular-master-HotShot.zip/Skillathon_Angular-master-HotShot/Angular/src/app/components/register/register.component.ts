import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CustomValidator } from '@services/custom-validator.service';
import { AuthService } from '@services/auth.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CricketService } from '@services/cricket.service';
import { AlertService } from '@services/alert.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  form: FormGroup;
  teams: string[] = [];
  submitted: boolean = false;
  constructor(private fb: FormBuilder, private auth:AuthService, private cricket:CricketService, public activeModal: NgbActiveModal, private alert:AlertService) { }

  ngOnInit() {
    this.setForm();
    this.loadData();
  }

  private setForm(): void {
    this.form = this.fb.group({
      name : [null, [Validators.required, Validators.minLength(3)]],
      email: [null,[Validators.required,CustomValidator.email]],
      team: [null, Validators.required],
      password : this.fb.control('', [Validators.required, Validators.minLength(8)]),
      confirmPassword : [null,Validators.required]
    },{
      validators: CustomValidator.passwordMatch('password','confirmPassword')
    });
  }

  loadData(){
    this.cricket.getFavouriteTeams().subscribe((response)=>{
      this.teams = response;
    });
  }

  hasError(control:string, validation:string) : boolean{
    return this.form.get(control).hasError(validation) && (this.form.get(control).touched || this.submitted);
  }

  onSubmit():void{
    this.submitted = true;
    if(this.form.valid){
      this.auth.register(this.form.value).subscribe((response)=>{
        this.activeModal.close();
        this.alert.show(response.message,response.success);
      },
      (error)=>{
        Object.keys(error.error).forEach(key=>this.form.get(key).setErrors({remote: error.error[key]}));
      });
    }
  }

}
