import { Component, OnInit } from '@angular/core';
import { CricketService } from '@services/cricket.service';
import { SeoService } from '@services/seo.service';
import { listAnimation } from '@animations/list-animation';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-manage-team',
  templateUrl: './manage-team.component.html',
  styleUrls: ['./manage-team.component.scss'],
  animations: [
    listAnimation
  ]
})
export class ManageTeamComponent implements OnInit {

  players: any[] = [];
  params:any;

  constructor(private seoService:SeoService, private cricketService:CricketService, private route:ActivatedRoute) {

   }

  ngOnInit() {
    this.params = this.route.snapshot.params;
    this.loadData();
  }

  loadData(){
    this.cricketService.getPlayers(this.params.season,this.params.team).subscribe((response)=>{
      this.seoService.setTitle('Manage Teams','(Manage Players)');
      this.players = response.players;
    });
  }

}
