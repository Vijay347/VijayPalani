import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BattingAverageComponent } from '@components/batting-average/batting-average.component';

describe('BattingAverageComponent', () => {
  let component: BattingAverageComponent;
  let fixture: ComponentFixture<BattingAverageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BattingAverageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BattingAverageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
