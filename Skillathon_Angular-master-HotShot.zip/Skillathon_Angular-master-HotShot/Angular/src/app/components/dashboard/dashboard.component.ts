import { Component, OnInit } from '@angular/core';
import { CricketService } from '@services/cricket.service';
import { SeoService } from '@services/seo.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import * as Cricket from '@interfaces/cricket.interface';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  seasons: number[] = [];
  mostRuns: Cricket.DashboardMostRuns[];
  highestScores: Cricket.DashboardHighestScore[];
  battingAverage: Cricket.DashboardBattingAverage[];
  batsmanRanking: Cricket.DashboardBatsmanRanking[];
  mostCenturies: Cricket.DashboardMostCentury[];
  mostFifties: Cricket.DashboardMostFifty[];
  form:FormGroup;
  page:number = 1;

  constructor(private seoService:SeoService, private cricketService:CricketService, private route:ActivatedRoute, private router:Router, private fb:FormBuilder) {
    
  }

  ngOnInit() {
    this.setForm();
    this.routeChange();
  }

  setForm(){
    this.form = this.fb.group({
      season: null
    });
    
  }

  loadData(params){
    this.cricketService.getDashboard(params).subscribe((response)=>{
      this.seasons = response.seasons;
      this.mostRuns = response.mostRuns;
      this.highestScores = response.highestScores;
      this.battingAverage = response.battingAverage;
      this.batsmanRanking = response.batsmanRanking;
      this.mostCenturies = response.mostCenturies;
      this.mostFifties = response.mostFifties;
      this.form.get('season').setValue(response.season);
      this.seoService.setTitle('Overview',response.season.toString());
    });
  }

  routeChange():void{
    this.route.queryParams.subscribe((params)=>{
      this.loadData(params);
    });
  }

  changeSeason(){
    this.router.navigate(['/dashboard'], { queryParams: { season : this.form.get('season').value }});
  }

}
