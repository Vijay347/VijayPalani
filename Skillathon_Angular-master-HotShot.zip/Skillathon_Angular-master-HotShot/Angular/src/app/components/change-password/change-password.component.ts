import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CustomValidator } from '@services/custom-validator.service';
import { AuthService } from '@services/auth.service';
import { AlertService } from '@services/alert.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit {

  form: FormGroup;
  submitted: boolean = false;
  constructor(private fb: FormBuilder, private auth:AuthService, private alert:AlertService, public activeModal: NgbActiveModal) { }

  ngOnInit() {
    this.setForm();
  }

  private setForm(): void {
    this.form = this.fb.group({
      password: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword : [null,Validators.required]
    },{
      validators: CustomValidator.passwordMatch('password','confirmPassword')
    });
  }

  hasError(control:string, validation:string) : boolean{
    return this.form.get(control).hasError(validation) && (this.form.get(control).touched || this.submitted);
  }

  onSubmit():void{
    this.submitted = true;
    if(this.form.valid){
      this.auth.changePassword(this.form.value).subscribe(response=>{
        this.activeModal.close();
        this.alert.show(response.message,response.success);
      });
    }
  }

}
