import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MostRunsComponent } from './most-runs.component';

describe('MostRunsComponent', () => {
  let component: MostRunsComponent;
  let fixture: ComponentFixture<MostRunsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MostRunsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MostRunsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
