import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '@services/auth.service';
import { CustomValidator } from '@services/custom-validator.service';
import { CricketService } from '@services/cricket.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { AlertService } from '@services/alert.service';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.scss']
})
export class UpdateProfileComponent implements OnInit {

  form: FormGroup;
  teams: string[] = [];
  submitted: boolean = false;
  constructor(private fb: FormBuilder, private auth:AuthService, private cricket:CricketService, private alert:AlertService, public activeModal: NgbActiveModal) { }

  ngOnInit() {
    this.setForm();
    this.loadData();
  }

  private setForm(): void {
    this.form = this.fb.group({
      name : [null, [Validators.required, Validators.minLength(3)]],
      email: [null,[Validators.required,CustomValidator.email]],
      team: [null, Validators.required]
    });
  }

  loadData(){
    this.cricket.getFavouriteTeams().subscribe((response)=>{
      this.teams = response;
      this.form.patchValue(this.auth.getUser());
    });
  }

  hasError(control:string, validation:string) : boolean{
    return this.form.get(control).hasError(validation) && (this.form.get(control).touched || this.submitted);
  }

  onSubmit():void{
    this.submitted = true;
    if(this.form.valid){
      this.auth.updateProfile(this.form.value).subscribe((response)=>{
        this.activeModal.close();
        this.alert.show(response.message,response.success);
      },
      (error)=>{
        Object.keys(error.error).forEach(key=>this.form.get(key).setErrors({remote: error.error[key]}));
      });
    }
  }
  
}
