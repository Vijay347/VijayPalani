import { Component, OnInit } from '@angular/core';
import { CricketService } from '@services/cricket.service';
import { SeoService } from '@services/seo.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { listAnimation } from '@animations/list-animation';
import { AlertService } from '@services/alert.service';

@Component({
  selector: 'app-team',
  templateUrl: './team.component.html',
  styleUrls: ['./team.component.scss'],
  animations: [
    listAnimation
  ]
})
export class TeamComponent implements OnInit {

   form:FormGroup;
   submitted:boolean = false;
 
   constructor(private seoService:SeoService, private cricketService:CricketService, private route:ActivatedRoute, private fb:FormBuilder, private alertService: AlertService, private router:Router) {
  
   }
 
   ngOnInit() {
    this.seoService.setTitle('Manage Teams','(Manage Player)');
     this.setForm();
     this.form.get('player').setValue(this.route.snapshot.params.player);
   }

   setForm(){
    this.form = this.fb.group({
      player: [null,Validators.required]
    });
  }
 

   hasError(control:string, validation:string) : boolean{
    return this.form.get(control).hasError(validation) && (this.form.get(control).touched || this.submitted);
  }

  onSubmit(){
    this.submitted = true;
    this.router.navigate(['/manage-teams/'+this.route.snapshot.params.season+'/'+this.route.snapshot.params.team]);
    this.alertService.show('Saved Successflly!',true);
  }
 
}
