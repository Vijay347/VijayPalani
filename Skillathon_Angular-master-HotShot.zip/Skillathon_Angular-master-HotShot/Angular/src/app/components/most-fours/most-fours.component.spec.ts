import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MostFoursComponent } from '@components/most-fours/most-fours.component';

describe('MostFoursComponent', () => {
  let component: MostFoursComponent;
  let fixture: ComponentFixture<MostFoursComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MostFoursComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MostFoursComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
