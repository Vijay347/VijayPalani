import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbDateAdapter, NgbPaginationModule, NgbModalModule, NgbDropdownModule, NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { library } from '@fortawesome/fontawesome-svg-core';
import { faEye, faPaperPlane, faEdit, faCheckCircle } from '@fortawesome/free-regular-svg-icons';
import { faSignInAlt, faBars, faChevronCircleRight, faExclamationTriangle, faSearch, faUser, faChevronRight, faChevronLeft, faSlidersH, faSave } from '@fortawesome/free-solid-svg-icons';
library.add(faSignInAlt, faEye, faBars, faPaperPlane, faChevronCircleRight, faExclamationTriangle, faSearch, faSignInAlt, faUser, faChevronRight, faChevronLeft, faBars, faSlidersH, faEdit, faSave, faCheckCircle);
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgSelectModule } from '@ng-select/ng-select';

import { DateAdapterService } from '@services/date-adapter.service';
import { AuthService } from '@services/auth.service';
import { AlertService } from '@services/alert.service';
import { InterceptorService } from '@services/interceptor.service';
import { CricketService } from '@services/cricket.service';
import { SeoService } from '@services/seo.service';
import { GuestGuard } from '@guards/guest.guard';
import { AuthGuard } from '@guards/auth.guard';

import { AppComponent } from './app.component';
import { AlertComponent } from '@components/alert/alert.component';
import { RegisterComponent } from '@components/register/register.component';
import { LoginComponent } from '@components/login/login.component';
import { UpdateProfileComponent } from '@components/update-profile/update-profile.component';
import { ChangePasswordComponent } from '@components/change-password/change-password.component';
import { LayoutComponent } from './components/layout/layout.component';
import { DashboardComponent } from '@components/dashboard/dashboard.component';
import { MostRunsComponent } from '@components/most-runs/most-runs.component';
import { BattingAverageComponent } from '@components/batting-average/batting-average.component';
import { FilterPipe } from './pipes/filter.pipe';
import { HighScoresComponent } from '@components/high-scores/high-scores.component';
import { MostCenturiesComponent } from '@components/most-centuries/most-centuries.component';
import { MostFiftiesComponent } from '@components/most-fifties/most-fifties.component';
import { MostSixesComponent } from '@components/most-sixes/most-sixes.component';
import { MostFoursComponent } from '@components/most-fours/most-fours.component';
import { BatsmanRankingComponent } from '@components/batsman-ranking/batsman-ranking.component';
import { MatchesComponent } from '@components/matches/matches.component';
import { MatchDetailsComponent } from './components/match-details/match-details.component';
import { TotalPipe } from './pipes/total.pipe';
import { PositivePipe } from './pipes/positive.pipe';
import { TeamComparisonComponent } from '@components/team-comparison/team-comparison.component';
import { ManageScoresComponent } from '@components/manage-scores/manage-scores.component';
import { ManageScoreComponent } from '@components/manage-score/manage-score.component';
import { ScoreComponent } from '@components/score/score.component';
import { ManageTeamsComponent } from '@components/manage-teams/manage-teams.component';
import { ManageTeamComponent } from '@components/manage-team/manage-team.component';
import { TeamComponent } from '@components/team/team.component';
import { MapPipe } from './pipes/map.pipe';

@NgModule({
  declarations: [
    AppComponent,
    AlertComponent,
    RegisterComponent,
    LoginComponent,
    UpdateProfileComponent,
    ChangePasswordComponent,
    LayoutComponent,
    DashboardComponent,
    MostRunsComponent,
    BattingAverageComponent,
    HighScoresComponent,
    MostCenturiesComponent,
    MostFiftiesComponent,
    MostSixesComponent,
    MostFoursComponent,
    BatsmanRankingComponent,
    MatchesComponent,
    FilterPipe,
    MatchDetailsComponent,
    TeamComparisonComponent,
    TotalPipe,
    PositivePipe,
    ManageScoresComponent,
    ManageScoreComponent,
    ScoreComponent,
    ManageTeamsComponent,
    ManageTeamComponent,
    TeamComponent,
    MapPipe
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    FontAwesomeModule,
    NgbPaginationModule,
    NgbModalModule,
    ReactiveFormsModule,
    NgbDropdownModule,
    NgxChartsModule,
    BrowserAnimationsModule,
    NgSelectModule,
    NgbTooltipModule
  ],
  providers: [
    { provide: NgbDateAdapter, useClass: DateAdapterService },
    { provide: 'Window', useValue: window },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptorService,
      multi: true
    },
    AuthService,
    AlertService,
    SeoService,
    AuthGuard,
    GuestGuard,
    CricketService,
  ],
  entryComponents: [
    AlertComponent,
    RegisterComponent,
    LoginComponent,
    ChangePasswordComponent,
    UpdateProfileComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
