
sp_helptext 'GetUserValue'

ALTER procedure AddUserValue 
(
 @UserLoginId Int,
 @UserName varchar(50),
 @Active bit,
 @Designation int,
 @DOB Date,
 @Password varchar(50),
 @Action varchar(10),
 @isExist bit out
 )
AS  
DECLARE @v_userid int

BEGIN  
if(@Action='insert')
BEGIN
If exists(select UserName from UserLogin U where UserName=@UserName)
BEGIN
set @isExist=1
END

ELSE
BEGIN
set @isExist=0
INSERT INTO UserLogin(UserName,Active) values(@UserName,@Active);

SET @v_userid= (SELECT TOP 1(UserLoginId) FROM UserLogin ORDER BY UserLoginId DESC);

INSERT INTO UserLoginDetails(UserLoginId,Designation,DOB,Password) VALUES(@v_userid,@Designation,@DOB,@Password);
  END
  END
  ELSE
  BEGIN
  Update UserLogin set Active=@Active where UserLoginId=@UserLoginId;
  Update UserLoginDetails set Designation=@Designation,Password=@Password where UserLoginId=@UserLoginId;
  END

END

EXEC AddUserValue @UserLoginId=1030,@UserName='',@Active=0,@Designation='pat',@DOB='',@Password='test',@Action='Update';

drop procedure AddUserValue;

--ALTER procedure GetUserValues 
--AS
--BEGIN
--Select UserName,Designation,DOB,Password from UserLogin,UserLoginDetails where UserLogin.UserLoginId=UserLoginDetails.UserLoginId;
--END

Alter procedure GetUserValues1
as
begin
select u.UserLoginId,u.UserName,u.Active,ul.DOB,ul.Password,d.Id as DesgId,d.Name as Designation from UserLogin u inner join UserLoginDetails ul on u.UserLoginId=ul.UserLoginId inner join Designation d on d.Id=ul.Designation
END

exec GetUserValues1

ALTER procedure DeleteValues (@id int)
As
BEGIN
Delete from UserLoginDetails where UserLoginId=@id;
Delete from UserLogin where UserLoginId=@id;
END

Exec DeleteValues 1028;

Alter procedure EditUser(@id int)
As
Begin
select u.UserLoginId,u.UserName,u.Active,ul.DOB,ul.Password,d.Id as DesgId,d.Name as Designation from UserLogin u inner join UserLoginDetails ul on u.UserLoginId=ul.UserLoginId inner join Designation d on d.Id=ul.Designation where u.UserLoginId=@id ;

END
exec EditUser 1

  
