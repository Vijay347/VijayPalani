SELECT * from [dbo].[UserLogin]
select * from  [dbo].[UserLoginDetails]

select * from [dbo].[UserLogin] ul
join [dbo].[UserLoginDetails] uld on ul.UserLoginId = uld.UserLoginId
Delete UserLoginDetails where UserDetailId=3