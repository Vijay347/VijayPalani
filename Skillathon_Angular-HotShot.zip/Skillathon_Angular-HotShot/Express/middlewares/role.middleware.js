const MESSAGE = require('../helpers/message.constant');
const PATH = require('../helpers/path.constant');

exports.requireRole = (requiredRole) => {
    return function (req, res, next) {
        if(req.user.roles.find(userRole=>userRole.role == requiredRole)){
            next();
        }
        else{
            res.status(401).json({ message : MESSAGE.NOT_AUTHORIZED, redirect: PATH.HOME });
        }   
    }
};