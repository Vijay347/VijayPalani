const Match = require('../models/match.model');

exports.getMatches = (query)=>{
    return Match.aggregate([
        {
            $facet: {
                matches: [
                    {
                        $match :{
                            season : query.season ? parseInt(query.season) : 2019
                        }
                    },
                    {
                        $sort : {
                            season: 1,
                            id : 1
                        }
                    }
                ],
                seasons: [
                    {
                        $group :{
                            _id : '$season'
                        }
                    },
                    {
                        $sort : {
                            _id : -1
                        }
                    }
                ]
            }
        },
        {
            $project: {
                matches: 1,
                seasons: '$seasons._id',
                total: {
                    $arrayElemAt: [ '$total.count', 0]
                }
            }
        }
    ]);
}

exports.getMostRuns = (query)=>{
    return Match.aggregate([
        {
            $facet: {
                seasons: [
                    {
                        $group :{
                            _id : '$season'
                        }
                    },
                    {
                        $sort : {
                            _id : -1
                        }
                    }
                ],
                batsmanRuns: [
                    {
                        $match :{
                            season : query.season ? parseInt(query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { $sum: 1 }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            runs: {
                                $first: '$runs'
                            }
                        }
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            matches: 1,
                            runs: 1,
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            runs : -1
                        }
                    },
                    { 
                        $limit: 50
                    }
                ]
            }
        },
        {
            $project: {
                seasons: '$seasons._id',
                batsmanRuns: 1
            }
        }
    ]);
}

exports.getMatch = (query)=>{
    return Match.aggregate([
        {
            $facet: {
                seasons: [
                    {
                        $group :{
                            _id : '$season'
                        }
                    },
                    {
                        $sort : {
                            _id : -1
                        }
                    }
                ],
                runs: [
                    {
                        $match :{
                            season : query.season ? parseInt(query.season) : 2017,
                            id: 57
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman'
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            },
                            balls: { 
                                $sum: 1 
                            },
                            fours: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $eq: ['$deliveries.batsman_runs',4]
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            sixes: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $eq: ['$deliveries.batsman_runs',6]
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            extras: { 
                                $sum: '$deliveries.extra_runs'
                            }
                        }
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            batsman: '$_id.batsman',
                            team: '$_id.team',
                            runs: 1,
                            balls: 1,
                            fours: 1,
                            sixes: 1,
                            extras: 1,
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            runs : -1
                        }
                    }
                ],
                overs: [
                    {
                        $match :{
                            id: 57
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.bowling_team',
                                bowler: '$deliveries.bowler',
                                overs: '$deliveries.over',
                                overs: {
                                    $sum : 1
                                }
                            },
                            runs: {
                                $sum : '$deliveries.total_runs'
                            },
                            wickets: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $ne: ['$deliveries.player_dismissed','']
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            dots: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $eq: ['$deliveries.total_runs',0]
                                        }, 
                                        1, 0
                                    ]
                                }
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                bowler: '$_id.bowler'
                            },
                            overs: {
                                $sum : '$_id.overs'
                            },
                            runs: {
                                $sum : '$runs'
                            },
                            maidens: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $eq: [{
                                                $sum : '$runs'
                                            },0]
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            wickets: { 
                                $sum: '$wickets'
                            },
                            dots: { 
                                $sum: '$dots'
                            }
                        }
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            bowler: '$_id.bowler',
                            team: '$_id.team',
                            overs: '$overs',
                            runs: '$overs',
                            maidens: 1,
                            wickets: 1,
                            dots: 1,
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            overs : -1
                        }
                    }
                ]
            }
        },
        {
            $project: {
                seasons: '$seasons._id',
                runs: 1,
                overs: 1
            }
        }
    ]);
}

exports.getMostFours = (query)=>{
    return Match.aggregate([
        {
            $facet: {
                seasons: [
                    {
                        $group :{
                            _id : '$season'
                        }
                    },
                    {
                        $sort : {
                            _id : -1
                        }
                    }
                ],
                batsmanRuns: [
                    {
                        $match :{
                            season : query.season ? parseInt(query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { 
                                    $sum: 1 
                                }
                            },
                            fours: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $eq: ['$deliveries.batsman_runs',4]
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            fours:{
                                $sum : '$fours'
                            },
                            runs: {
                                $sum : '$runs'
                            }
                        }
                    },
                    { 
                        $match : { 
                            fours: { $gt: 0 } 
                        } 
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            matches: 1,
                            fours: 1,
                            runs: 1,
                            average:  { $divide: [ "$runs", '$matches' ] },
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            fours : -1
                        }
                    },
                    { 
                        $limit: 50
                    }
                ]
            }
        },
        {
            $project: {
                seasons: '$seasons._id',
                batsmanRuns: 1
            }
        }
    ]);
}

exports.getMostSixes = (query)=>{
    return Match.aggregate([
        {
            $facet: {
                seasons: [
                    {
                        $group :{
                            _id : '$season'
                        }
                    },
                    {
                        $sort : {
                            _id : -1
                        }
                    }
                ],
                batsmanRuns: [
                    {
                        $match :{
                            season : query.season ? parseInt(query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { 
                                    $sum: 1 
                                }
                            },
                            sixes: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $eq: ['$deliveries.batsman_runs',6]
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            sixes:{
                                $sum : '$sixes'
                            },
                            runs: {
                                $sum : '$runs'
                            }
                        }
                    },
                    { 
                        $match : { 
                            sixes: { $gt: 0 } 
                        } 
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            matches: 1,
                            sixes: 1,
                            runs: 1,
                            average:  { $divide: [ "$runs", '$matches' ] },
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            sixes : -1
                        }
                    },
                    { 
                        $limit: 50
                    }
                ]
            }
        },
        {
            $project: {
                seasons: '$seasons._id',
                batsmanRuns: 1
            }
        }
    ]);
}

exports.getMostCenturies = (query)=>{
    return Match.aggregate([
        {
            $facet: {
                seasons: [
                    {
                        $group :{
                            _id : '$season'
                        }
                    },
                    {
                        $sort : {
                            _id : -1
                        }
                    }
                ],
                batsmanRuns: [
                    {
                        $match :{
                            season : query.season ? parseInt(query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { 
                                    $sum: 1 
                                }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            hundreds: { 
                                $sum: {
                                    $cond: [
                                        { 
                                            $gt: ['$runs',99]
                                        }, 
                                        1, 0
                                    ]
                                }
                            },
                            runs: {
                                $sum : '$runs'
                            }
                        }
                    },
                    { 
                        $match : { 
                            hundreds: { $gt: 0 } 
                        } 
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            matches: 1,
                            hundreds: 1,
                            runs: 1,
                            average:  { $divide: [ "$runs", '$matches' ] },
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            hundreds : -1
                        }
                    },
                    { 
                        $limit: 50
                    }
                ]
            }
        },
        {
            $project: {
                seasons: '$seasons._id',
                batsmanRuns: 1
            }
        }
    ]);
}

exports.getMostFifties = (query)=>{
    return Match.aggregate([
        {
            $facet: {
                seasons: [
                    {
                        $group :{
                            _id : '$season'
                        }
                    },
                    {
                        $sort : {
                            _id : -1
                        }
                    }
                ],
                batsmanRuns: [
                    {
                        $match :{
                            season : query.season ? parseInt(query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { 
                                    $sum: 1 
                                }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            fifties: { 
                                $sum: {
                                    $cond: [
                                        {
                                            $and : [
                                                { 
                                                    $lt: ['$runs',100]
                                                },
                                                { 
                                                    $gt: ['$runs',50]
                                                }
                                            ]
                                        },
                                        1, 0
                                    ]
                                }
                            },
                            runs: {
                                $sum : '$runs'
                            }
                        }
                    },
                    { 
                        $match : { 
                            fifties: { $gt: 0 } 
                        } 
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            matches: 1,
                            fifties: 1,
                            runs: 1,
                            average:  { $divide: [ "$runs", '$matches' ] },
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            fifties : -1
                        }
                    },
                    { 
                        $limit: 50
                    }
                ]
            }
        },
        {
            $project: {
                seasons: '$seasons._id',
                batsmanRuns: 1
            }
        }
    ]);
}

exports.getHighestScores = (query)=>{
    return Match.aggregate([
        {
            $facet: {
                seasons: [
                    {
                        $group :{
                            _id : '$season'
                        }
                    },
                    {
                        $sort : {
                            _id : -1
                        }
                    }
                ],
                batsmanRuns: [
                    {
                        $match :{
                            season : query.season ? parseInt(query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id'
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            runs: 1,
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            runs : -1
                        }
                    },
                    { 
                        $limit: 50
                    }
                ]
            }
        },
        {
            $project: {
                seasons: '$seasons._id',
                batsmanRuns: 1
            }
        }
    ]);
}

exports.getBatttingAverage = (query)=>{
    return Match.aggregate([
        {
            $facet: {
                seasons: [
                    {
                        $group :{
                            _id : '$season'
                        }
                    },
                    {
                        $sort : {
                            _id : -1
                        }
                    }
                ],
                batsmanRuns: [
                    {
                        $match :{
                            season : query.season ? parseInt(query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { $sum: 1 }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            runs: {
                                $sum : '$runs'
                            }
                        }
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            matches: 1,
                            runs: 1,
                            average:  { $divide: [ "$runs", '$matches' ] },
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            average : -1
                        }
                    },
                    {
                        $group : {
                            _id: { },
                            items: { 
                                $push: '$$ROOT'
                            }
                        }
                    },
                    { 
                        $unwind: { 
                            path: '$items',
                            includeArrayIndex: 'items.rank'
                        } 
                    },
                    {
                        $project : {
                            season: '$items.season',
                            team: '$items.team',
                            batsman: '$items.batsman',
                            matches: '$items.matches',
                            runs: '$items.runs',
                            average: '$items.average',
                            rank: { 
                                $add: [ '$items.rank', 1 ] 
                            },
                            _id: 0
                        }
                    },
                    { 
                        $limit: 50
                    }
                ]
            }
        },
        {
            $project: {
                seasons: '$seasons._id',
                batsmanRuns: 1
            }
        }
    ]);
}


exports.getBatsmanRunsChart = (query)=>{
    return Match.aggregate([
        {
            $facet: {
                seasons: [
                    {
                        $group :{
                            _id : '$season'
                        }
                    },
                    {
                        $sort : {
                            _id : -1
                        }
                    }
                ],
                batsmanRuns: [
                    {
                        $match :{
                            season : query.season ? parseInt(query.season) : 2019
                        }
                    },
                    {
                        $lookup:{  
                            from: 'deliveries', 
                            localField: 'id', 
                            foreignField: 'match_id', 
                            as: 'deliveries'
                        }
                    },
                    {
                        $unwind: {
                            path: "$deliveries",
                            preserveNullAndEmptyArrays: true
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$season',
                                team: '$deliveries.batting_team',
                                batsman: '$deliveries.batsman',
                                match_id:  '$deliveries.match_id',
                                matches: { $sum: 1 }
                            },
                            runs: {
                                $sum : '$deliveries.batsman_runs'
                            }
                        }
                    },
                    {
                        $group : {
                            _id: {
                                season: '$_id.season',
                                team: '$_id.team',
                                batsman: '$_id.batsman'
                            },
                            matches: {
                                $sum : '$_id.matches'
                            },
                            runs: {
                                $first: '$runs'
                            }
                        }
                    },
                    {
                        $project : {
                            season: '$_id.season',
                            team: '$_id.team',
                            batsman: '$_id.batsman',
                            matches: 1,
                            runs: 1,
                            _id: 0
                        }
                    },
                    {
                        $sort : {
                            runs : -1
                        }
                    },
                    {
                        $match: {
                            batsman : {
                                $regex: query.search ? query.search : '', 
                                $options: 'i'
                            }
                        }
                    },
                    {
                        $project : {
                            name: '$batsman',
                            value: '$runs',
                            season: 1
                        }
                    },
                    { 
                        $limit: 50
                    }
                ]
            }
        },
        {
            $project: {
                seasons: '$seasons._id',
                batsmanRuns: 1
            }
        }
    ]);
}