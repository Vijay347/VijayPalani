const User = require('../models/user.model');

exports.register = (user)=>{
    return User.create({
        name: user.name,
        email: user.email,
        password: user.password,
        roles: ['USER']
    });
}
exports.forgotPassword = (email)=>{
    return User.countDocuments({ email : email });
}