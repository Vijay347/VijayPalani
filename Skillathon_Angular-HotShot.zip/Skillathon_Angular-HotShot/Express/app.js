const express = require('express');
const path = require('path');
const logger = require('morgan');
const passport = require('passport');
const errorHandler = require('./helpers/error.handler');
const indexRouter = require('./routes/index');
const authRouter = require('./routes/auth.routes');
const cricketRouter = require('./routes/cricket.routes');

const app = express();
app.use(logger('dev'));
app.set('json spaces', 2);
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(passport.initialize());
require('./support/mongoose.connection');
require('./support/passport.auth');

app.use('/', indexRouter);
app.use('/api/auth',authRouter);
app.use('/api/cricket',cricketRouter);

app.use(errorHandler);

const port = process.env.NODE_ENV === 'production' ? process.env.PORT : 3000;
app.listen(port, () => {
    console.log(`Server is listening on port ${port}`);
});