const router = require('express').Router();
const controller = require('../controllers/cricket.controller');

router.get('/matches', controller.getMatches);
router.get('/most-runs', controller.getMostRuns);
router.get('/batsman-average', controller.getBatttingAverage);
router.get('/batsman-runs-chart', controller.getBatsmanRunsChart);

//router.get('/batsman-ranking-charts', controller.getBatsmanScores);

module.exports = router;