const router = require('express').Router();
const passport = require('passport');
const controller = require('../controllers/auth.controller');

router.post('/register', controller.register);
router.post('/forgot-password', controller.forgotPassword);
router.post('/reset-password', passport.authenticate('jwt',{ session: false, failWithError: true }), controller.resetPassword);
router.post('/login',passport.authenticate('local',{ failWithError: true }), controller.login);

module.exports = router;