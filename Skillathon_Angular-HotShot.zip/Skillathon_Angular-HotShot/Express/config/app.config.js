module.exports = {
    MONGODB_URI: 'mongodb://localhost:27017/PremierLeague',
    RECAPTCHA:{
        SITE_KEY: '6LfxBo0UAAAAAOpCZHH61Ug0LaGZRa43haJ0WNa8',
        SECRET_KEY: '6LfxBo0UAAAAAOj27NVT2PwErPIOTU0o9O4naJ1g'
    },
    JWT:{
        SECRET: 'Eq4ny1obX/uK25Zcx6gynoYclCaDnYnO+AFMql/2RPGpX+v4Ce3suQIMJI3aK111H7AsG/CYhKoJMLDR0vhJmssaOsHJNH3etV5A1lXJWL0b91DGHpCU75SBBSdHobmFmNukrJXYSgz6Microsoft FndRwdIyMKaaXjhlJergPX8XIlJSjmu2FTx23jM/N40SQlIzID+8HJ5ICOfOMJqTjZGLVLE2nueKgEvh+bbt1SwkSvKP4RaVkYb5zMJoEHFNgPlJmTW4Lb7Cc7wOtswr7ChTi+HzMMRCRRhF73brMFqz/yLYCopyright ZbPc/n81L6swJj+9ZdzIp1VufA==',
        EXPIRY: 86400
    }
}