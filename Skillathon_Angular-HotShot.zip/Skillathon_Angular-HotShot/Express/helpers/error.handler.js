const MESSAGE = require('../helpers/message.constant');
module.exports = (err, req, res, next)=>{
    if (typeof (err) === 'string') {
        res.status(400).json({ message: err, success: false });
    }
    else if (err.name === 'AuthenticationError'){
        if(req.path == '/api/auth/login')
            res.status(401).json({ message: MESSAGE.WRONG_CREDENTIALS, success: false });
        else
            res.status(401).json({ message: MESSAGE.SESSION_EXPIRED, success: false, redirect: '/auth/login' });
    }
    else if (err.name === 'MongoError' && err.code === 11000){
        if(err.errmsg.includes('email')){
            res.status(422).json({ email: MESSAGE.EMAIL_EXISTS });
        }
        else if(err.errmsg.includes('mobile')){
            res.status(422).json({ mobile: MESSAGE.MOBILE_EXISTS });
        }
    }
    else{
        res.status(500).json({ message: err.message, success: false });
    }
}