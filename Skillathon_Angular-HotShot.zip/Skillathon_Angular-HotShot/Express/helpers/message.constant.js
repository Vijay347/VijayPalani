module.exports = {
    UNEXPECTED_ERROR: 'An unexpected error has occurred.',
    TOO_MANY_REQUESTS: 'Too many request\'s received.',
    NOT_A_ROBOT: 'Verify you\'re not a robot.',
    REGISTERED: 'You have been successfully registered.',
    WRONG_CREDENTIALS: 'These credentials do not match our records.',
    PASSWORD_CHANGED: 'Your password has been changed successfully!',
    EMAIL_EXISTS: 'Email already exists.',
    MOBILE_EXISTS: 'Mobile Number already exists.',
    SESSION_EXPIRED: 'Your session has expired. Please log in again.',
    SAVED: 'Saved Successfully!',
    UPDATED: 'Updated Successfully!',
    DELETED: 'Deleted Successfully!',
    UPLOAD_ERROR: 'An unknown error occurred when uploading.',
    MIME_TYPE_ERROR: 'Only JPEG, PNG and GIF images are allowed.'
};