module.exports = {
    HOME: '/',
    AUTH:{
        FORGOT_PASSWORD: '/auth/forgot-password',
        RESET_PASSWORD: '/auth/reset-password',
    }
};