const config = require('../config/app.config');
const jwt = require('jsonwebtoken');
const AuthService = require('../services/auth.service');
const MESSAGE = require('../helpers/message.constant');
const PATH = require('../helpers/path.constant');

exports.register = (req, res, next) => {
    AuthService.register(req.body).then(user=>{
        res.json({
            user : user,
            token: jwt.sign({ id: user._id }, config.JWT.SECRET, { expiresIn: config.JWT.EXPIRY }),
            expiresIn: config.JWT.EXPIRY,
            redirect: PATH.HOME
        });
    }).catch((error)=>{
        next(error);
    });
};
exports.forgotPassword = (req, res, next) => {
    AuthService.forgotPassword(req.body.email).then(count=>{
        if(count){
            res.json({ redirect : PATH.FORGOT_PASSWORD });
        }else
            res.json({ message : MESSAGE.USER_NOT_FOUND, success: false });
    }).catch((error)=>{
        next(error);
    });
};
exports.resetPassword = (req, res) => {
    req.user.password = req.body.password;
    req.user.save().then(()=>{
        res.json({ message: MESSAGE.PASSWORD_CHANGED, success: true, redirect : PATH.HOME });
    }).catch((error)=>{
        next(error);
    });
};

exports.login = (req, res, next) => {
    res.json({ token : jwt.sign({ id: req.user._id }, config.JWT.SECRET, { expiresIn: config.JWT.EXPIRY }), user: req.user, expiresIn: config.JWT.EXPIRY, redirect : PATH.HOME });
}