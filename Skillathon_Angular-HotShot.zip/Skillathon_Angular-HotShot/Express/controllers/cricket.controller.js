const CricketService = require('../services/cricket.service');
const config = require('../config/app.config');
const MESSAGE = require('../helpers/message.constant');
const PATH = require('../helpers/path.constant');

exports.getMatches = (req, res, next) => {
    CricketService.getMatches(req.query).then((matches)=>{
        res.json(matches[0]);
    }).catch((error)=>{
        next(error);
    });
};

exports.getMostRuns = (req, res, next) => {
    CricketService.getMostRuns(req.query).then((batsmanScores)=>{
        res.json(batsmanScores[0]);
    }).catch((error)=>{
        next(error);
    });
};

exports.getBatttingAverage = (req, res, next) => {
    CricketService.getBatttingAverage(req.query).then((batsmanScores)=>{
        res.json(batsmanScores[0]);
    }).catch((error)=>{
        next(error);
    });
};

exports.getBatsmanRunsChart = (req, res, next) => {
    CricketService.getBatsmanRunsChart(req.query).then((batsmanScores)=>{
        res.json(batsmanScores[0]);
    }).catch((error)=>{
        next(error);
    });
};

