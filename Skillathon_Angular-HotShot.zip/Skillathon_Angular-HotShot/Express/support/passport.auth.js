const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const JwtStrategy = require('passport-jwt').Strategy;
const ExtractJwt = require('passport-jwt').ExtractJwt;
const User = require('../models/user.model');
const config = require('../config/app.config');

passport.use(new LocalStrategy({
    usernameField: 'email',
    passwordField: 'password',
    session: false
  },
  function(email, password, done) {
    User.findOne({ email : email }).then(user=>{
        if (!user)
            return done(null, false);
        else if(!user.verifyPassword(password))
            return done(null, false);
        else
            return done(null, user);
    }).catch(err=>done(err, false));
  }
));

passport.use(new JwtStrategy({
    jwtFromRequest : ExtractJwt.fromAuthHeaderAsBearerToken(),
    secretOrKey : config.JWT.SECRET,
    passReqToCallback: true
}, function(req, jwt_payload, done) {
    User.findOne({_id: jwt_payload.id}).then(user=>{
        if (user) {
            return done(null, user);
        } else {
            return done(null, false);
        }
    }).catch(err=>done(err, false));
}));

passport.serializeUser(function(user, done) {
    done(null, user);
});
  
passport.deserializeUser(function(user, done) {
    done(null, user);
});