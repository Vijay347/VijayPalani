import { Injectable } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { AlertComponent } from '@components/alert/alert.component';

@Injectable()
export class AlertService {

  constructor(private ngbModal: NgbModal) { }

  show(message: string, success: boolean) : NgbModalRef {
    let modalRef:NgbModalRef = this.ngbModal.open(AlertComponent, {
      centered: true,
      backdrop : 'static',
      keyboard : false,
      windowClass: 'alert-modal'
    });
    modalRef.componentInstance.message = message;
    modalRef.componentInstance.success = success;
    return modalRef;
  }

}
