import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { Title } from '@angular/platform-browser';
import { Title as SeoTitle } from '../interfaces/seo.interface';

@Injectable({
  providedIn: 'root'
})
export class SeoService {

  private $title:Subject<SeoTitle> = new Subject<SeoTitle>();

  constructor(private titleService: Title) { }

  setTitle(title: string, subTitle: string = ''):void{
    this.titleService.setTitle(title);
    this.$title.next({ title : title, subTitle : subTitle });
  }

  getTitle() : Observable<SeoTitle>{
    return this.$title.asObservable();
  }

}
