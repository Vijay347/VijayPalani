import { TestBed } from '@angular/core/testing';

import { CustomValidator } from './custom-validator.service';

describe('CustomValidator', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CustomValidator = TestBed.get(CustomValidator);
    expect(service).toBeTruthy();
  });
});
