import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';
import { Router } from '@angular/router';
import { LoaderService } from './loader.service';
import { AuthService } from './auth.service';
import { AlertService } from './alert.service';

@Injectable({
  providedIn: 'root'
})
export class InterceptorService implements HttpInterceptor {

  private count: number = 0;

  constructor(private auth: AuthService, private alert:AlertService, private router: Router, private loader:LoaderService) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if((++this.count) === 1){
      this.loader.show();
    }
    if(this.auth.getToken()){
      request = request.clone({
        setHeaders: {
          Authorization: `Bearer ${this.auth.getToken()}`
        }
      });
    }
    return next.handle(request).pipe(catchError((err: HttpErrorResponse) => {
        if(err instanceof HttpErrorResponse) {
          if(err.error && err.error.message){
            this.alert.show(err.error.message,false);
            if(err.error.redirect)
              this.router.navigate([err.error.redirect]);
          }
          else if(err.status != 422)
            this.alert.show('An unexpected error has occurred. Please try again later.',false);
        }
        return throwError(err);
      }),
      finalize(() => {
        if((--this.count) === 0){
          this.loader.hide();
        }
      })
    )
  }

}
