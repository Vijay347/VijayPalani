import { Component, OnInit, ChangeDetectorRef, HostBinding } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AuthService } from '@services/auth.service';
import { LoaderService } from '@services/loader.service';
import { SeoService } from '@services/seo.service';
import { AlertService } from '@services/alert.service';
import { tns } from "tiny-slider/src/tiny-slider"

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  title:string;
  subTitle:string;

  user: any;
  loggedIn: boolean = false;
  loading: boolean = false;
  dt: Date = new Date();
  module:string;
  $timeout;
  
  @HostBinding('class') class:string;

  constructor(private router: Router, private auth: AuthService, private cd: ChangeDetectorRef, private loader: LoaderService, private seoService:SeoService, private alertService: AlertService, private modalService: NgbModal) {

  }

  ngOnInit() {
    this.router.events.subscribe((event)=>{
      if(event instanceof NavigationStart){
        this.seoService.setTitle(null);
        this.modalService.dismissAll();
        if(event.url.startsWith('/auth/')){
          this.class = 'has-auth';
        }else{
          this.class = '';
        }
      }
    });
    if(this.auth.loggedIn()) {
      this.loggedIn = true;
      this.user = this.auth.getUser();
      this.setExpiry();
    }
    this.auth.loginHook().subscribe(user => {
      this.loggedIn = true;
      this.user = user;
      this.clearExpiry();
      this.setExpiry();
    });
    this.auth.logoutHook().subscribe(() => {
      this.loggedIn = false;
      this.user = {};
      this.clearExpiry();
    });
    this.loader.getState().subscribe(status => {
      this.loading = status;
      this.cd.detectChanges();
    });
    this.seoService.getTitle().subscribe((seo)=>{
      this.title = seo.title;
      this.subTitle = seo.subTitle;
    });
    tns({
      container: '.my-slider',
      items: 1,
      autoplay: true,
      autoplayButtonOutput: false,
      nav: false,
      controlsText: ['<i class="arrow left"></i>','<i class="arrow right"></i>']
    });
  }

  logout(){
    this.auth.logout();
  }

  setExpiry(){
    this.$timeout = setTimeout(()=>{
      this.alertService.show('Your session has expired. Please log in.',false).result.then(()=>{
        this.auth.logout();
        this.router.navigate(['/auth/login']);
      },() => {
        this.auth.logout();
        this.router.navigate(['/auth/login']);
      });
    },this.auth.getExpiry());
  }

  clearExpiry(){
    if(this.$timeout){
      clearTimeout(this.$timeout);
    }
  }

  open(content) {
    this.modalService.open(content,{ windowClass : 'sidebar-nav', backdrop: 'static' });
  } 

}