import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BatsmanScoreChartComponent } from './batsman-score-chart.component';

describe('BatsmanScoreChartComponent', () => {
  let component: BatsmanScoreChartComponent;
  let fixture: ComponentFixture<BatsmanScoreChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BatsmanScoreChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BatsmanScoreChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
