export interface Status{
    message: string,
    success: boolean,
    redirect?: string
}