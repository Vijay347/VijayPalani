import { trigger, style, transition, animate, keyframes, query, stagger } from '@angular/animations';
export const listAnimation = trigger('listAnimation', [
    transition('* => *', [
      query(':enter', style({ opacity: 0 }), {optional: true}),
      query(':enter', stagger('100ms', [
        animate('800ms ease-in', keyframes([
          style({opacity: 0, transform: 'scale(0.4)', offset: 0}),
          style({opacity: 1, transform: 'scale(1)', offset: 1.0}),
        ]))
      ]), {optional: true})
    ])
])