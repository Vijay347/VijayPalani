import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegisterComponent } from '@components/register/register.component';
import { LoginComponent } from '@components/login/login.component';
import { ForgotPasswordComponent } from '@components/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from '@components/reset-password/reset-password.component';
import { GuestGuard } from '@guards/guest.guard';
import { AuthGuard } from '@guards/auth.guard';
import { DashboardComponent } from '@components/dashboard/dashboard.component';
import { BatsmanScoreComponent } from '@components/batsman-score/batsman-score.component';
import { BatsmanScoreChartComponent } from '@components/batsman-score-chart/batsman-score-chart.component';
import { BatsmanRankingComponent } from '@components/batsman-ranking/batsman-ranking.component';

const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'batsman-runs', component: BatsmanScoreComponent },
  { path: 'batsman-runs-chart', component: BatsmanScoreChartComponent },
  { path: 'batsman-ranking', component: BatsmanRankingComponent },
  { path: 'auth/register', component: RegisterComponent, canActivate: [GuestGuard] },
  { path: 'auth/forgot-password', component: ForgotPasswordComponent, canActivate: [GuestGuard] },
  { path: 'auth/reset-password', component: ResetPasswordComponent, canActivate: [AuthGuard] },
  { path: 'auth/login', component: LoginComponent, canActivate: [GuestGuard] }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    scrollPositionRestoration: 'top',
    anchorScrolling: 'enabled'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
