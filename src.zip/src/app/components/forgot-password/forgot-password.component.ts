import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '@services/auth.service';
import { AlertService } from '@services/alert.service';
import { Router } from '@angular/router';
import { CustomValidator } from '@services/custom-validator.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {

  form: FormGroup;
  submitted: boolean = false;
  constructor(private fb: FormBuilder, private router:Router, private auth:AuthService, private alert:AlertService, @Inject('Window') private window: Window) { }

  ngOnInit() {
    this.setForm();
  }

  private setForm(): void {
    this.form = this.fb.group({
      email : [null, [Validators.required,CustomValidator.email]],
      'g-recaptcha-response': [null, Validators.required]
    });
  }

  hasError(control:string, validation:string) : boolean{
    return this.form.get(control).hasError(validation) && (this.form.get(control).touched || this.submitted);
  }

  onSubmit(): void{
    this.submitted = true;
    if(this.form.valid){
      this.auth.forgotPassword(this.form.value).subscribe(data => {
        if(data.redirect){
          this.router.navigate([data.redirect]);
        }else{
          this.alert.show(data.message,data.success);
          this.form.get('g-recaptcha-response').reset();
        }
      },error=>{
        Object.keys(error.error).forEach(key=>this.form.get(key).setErrors({remote: error.error[key]}));
        this.form.get('g-recaptcha-response').reset();
        this.form.get('g-recaptcha-response').markAsUntouched();
      });
    }
  }
  
}
