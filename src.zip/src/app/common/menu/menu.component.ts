import { Component, OnInit, ElementRef, Renderer, ViewChildren, QueryList } from '@angular/core';
import { CommonService } from '../../services/common.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})


export class MenuComponent implements OnInit {
  response: any;
  items: any;
  newitems: any;
      message: any;
    subscription: Subscription;
    alerts = []; 
  constructor(private commService: CommonService, private elementRef: ElementRef<any>) {
// this.subscription = this.commService.getMessage().subscribe(message => { this.message = message; });
  }

  ngOnInit() {
  this.commService.dataList.subscribe(message => this.message = message)
  console.log(this.message);

    // this.commService.getMenuDetails().subscribe(data => {
    //   this.response = data;
    //   this.items = this.response.menuDetails
    //  // console.log(this.items);
    // });
  
  }


  showMenu = function () {
    this.newitems = this.elementRef.nativeElement.querySelectorAll('.circle a');
    console.log(this.newitems);
    for (var i = 0, l = this.newitems.length; i < l; i++) {
      this.newitems[i].style.left = (50 - 35 * Math.cos(-0.5 * Math.PI - 2 * (1 / l) * i * Math.PI)).toFixed(4) + "%";

      this.newitems[i].style.top = (50 + 35 * Math.sin(-0.5 * Math.PI - 2 * (1 / l) * i * Math.PI)).toFixed(4) + "%";
    }
    this.elementRef.nativeElement.querySelector('.circle').classList.toggle('open');
  }



}



