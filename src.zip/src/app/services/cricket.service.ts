import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CricketService {

  private API_PATH:string = '/api/cricket';

  constructor(private http: HttpClient) { }

  getMatches(queryParams) : Observable<any>{
    return this.http.get<any>(`${this.API_PATH}/matches`,{ params: queryParams });
  }

  getBatsmanRuns(queryParams) : Observable<any>{
    return this.http.get<any>(`${this.API_PATH}/batsman-runs`,{ params: queryParams });
  }

  getBatsmanRunsChart(queryParams) : Observable<any>{
    return this.http.get<any>(`${this.API_PATH}/batsman-runs-chart`,{ params: queryParams });
  }

  getBatsmanRankings(queryParams) : Observable<any>{
    return this.http.get<any>(`${this.API_PATH}/batsman-ranking`,{ params: queryParams });
  }

  getBatsmanRankingsChart(queryParams) : Observable<any>{
    return this.http.get<any>(`${this.API_PATH}/batsman-ranking-chart`,{ params: queryParams });
  }

}
