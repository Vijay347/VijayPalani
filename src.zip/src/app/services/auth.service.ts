import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Register, TokenResponse, User, ForgotPassword, Login, OTP, ResetPassword } from '@interfaces/auth.interface';
import { Status } from '@interfaces/status.interface';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

	API: string = `/api/auth`;

	private loginEvent: Subject<User> = new Subject<User>();
	private logoutEvent: Subject<boolean> = new Subject<boolean>();

	constructor(private http: HttpClient, private router:Router) { }

	private setSession(response: TokenResponse) {
		if(response.token){
			localStorage.setItem('token',response.token);
		}
		if(response.expiresIn){
			localStorage.setItem('expiresIn',new Date(new Date().getTime()+response.expiresIn*1000).toString());
		}
		if(response.user) {
			localStorage.setItem('user',JSON.stringify(response.user));
		}
		this.loginEvent.next(response.user);
	}

	private clearSession() {
		localStorage.removeItem('user');
		localStorage.removeItem('token');
		localStorage.removeItem('expiresIn');
		this.logoutEvent.next(true);
	}

	getUser(): User {
		const userString: string = localStorage.getItem('user');
		return userString ? JSON.parse(userString) : userString;
	}

	getToken(): string{
		const tokenString:string = localStorage.getItem('token');
		return tokenString ? tokenString : tokenString;
	}

	getExpiry(): number{
		const expiresIn = localStorage.getItem('expiresIn');
		return (new Date(expiresIn).getTime() - new Date().getTime());
	}

	tokenExpired(): boolean{
		const expiresIn = localStorage.getItem('expiresIn');
		return !(expiresIn && (new Date() < new Date(expiresIn)));
	}
	
	loggedIn(): boolean {
		if(!localStorage.getItem('token')){
			return false;
		}
		if(localStorage.getItem('token') && this.tokenExpired()){
			this.logout();
			this.router.navigate(['/']);
			return false;
		}else
			return true;
	}

	loginHook(): Observable<User> {
		return this.loginEvent.asObservable();
	}

	logoutHook(): Observable<boolean> {
		return this.logoutEvent.asObservable();
	}

	register(register: Register): Observable<TokenResponse> {
		return this.http.post<TokenResponse>(`${this.API}/register`,register).pipe(tap(response => this.setSession(response)));
	}

	sendOTP(): Observable<Status> {
		return this.http.get<Status>(`${this.API}/send-otp`);
	}

	verifyOTP(otp: OTP): Observable<TokenResponse> {
		return this.http.post<TokenResponse>(`${this.API}/verify-otp`,otp).pipe(tap(response => this.setSession(response)));
	}

	forgotPassword(forgotPassword:ForgotPassword): Observable<Status> {
		return this.http.post<Status>(`${this.API}/forgot-password`,forgotPassword);
	}

	forgotPasswordOTP(otp: OTP): Observable<Status> {
		return this.http.post<Status>(`${this.API}/forgot-password-otp`,otp);
	}

	forgotPasswordPVerify(otp: OTP): Observable<TokenResponse> {
		return this.http.post<TokenResponse>(`${this.API}/forgot-password-verify`,otp).pipe(tap(response => this.setSession(response)));
	}

	login(login: Login): Observable<TokenResponse> {
		return this.http.post<TokenResponse>(`${this.API}/login`,login).pipe(tap(response => this.setSession(response)));
	}

	resetPassword(resetPassword:ResetPassword): Observable<Status> {
		return this.http.post<Status>(`${this.API}/reset-password`,resetPassword);
	}

	logout(): void {
		this.clearSession();
	}
}
