﻿using Capsule_TaskManagerDL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capsule_TaskManagerDL
{
    public class UserDL
    {
        #region GetUserDetails
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<GET_USER_DETAILS_Result> GetUserDetails()
        {
            using (TaskManagerEntities db = new TaskManagerEntities())
            {
                var vUserDetails = db.GET_USER_DETAILS().ToList();
                return vUserDetails;
            }

        }
        #endregion


        #region InsertUserDetails
        /// <summary>
        /// 
        /// </summary>
        /// <param name="objGET_USER_DETAILS_Result"></param>
        /// <returns></returns>

        public string InsertUserDetails(GET_USER_DETAILS_Result objGET_USER_DETAILS_Result)
        {
            using (TaskManagerEntities db = new TaskManagerEntities())
            {
                objGET_USER_DETAILS_Result.Project_ID = objGET_USER_DETAILS_Result.Project_ID == null ? 0 : objGET_USER_DETAILS_Result.Project_ID;
                var vInsertProjectDetails = db.INSERT_USER_DETAILS(objGET_USER_DETAILS_Result.User_ID, objGET_USER_DETAILS_Result.First_Name, objGET_USER_DETAILS_Result.Last_Name, objGET_USER_DETAILS_Result.Employee_ID, objGET_USER_DETAILS_Result.Project_ID, objGET_USER_DETAILS_Result.Task_ID, objGET_USER_DETAILS_Result.Action);

                db.SaveChanges();
                return Convert.ToString(vInsertProjectDetails);
            }

        }
        #endregion

    }
}
