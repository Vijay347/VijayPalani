﻿using Capsule_TaskManagerDL.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Capsule_TaskManagerDL
{
    public class ProjectDL
    {
        #region GetProjectDetails
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<GET_PROJECT_DETAILS_Result> GetProjectDetails()
        {
            using (TaskManagerEntities db = new TaskManagerEntities())
            {
                var vProjectDetails = db.GET_PROJECT_DETAILS().ToList();
                return vProjectDetails;
            }

        }
        #endregion
        
        #region InsertProjectDetails
        /// <summary>
        /// 
        /// </summary>
        /// <param name="objGET_PROJECT_DETAILS_Result"></param>
        /// <returns></returns>

        public string InsertProjectDetails(GET_PROJECT_DETAILS_Result objGET_PROJECT_DETAILS_Result)
        {
            using (TaskManagerEntities db = new TaskManagerEntities())
            {
                objGET_PROJECT_DETAILS_Result.Project_ID = objGET_PROJECT_DETAILS_Result.Project_ID == null ? 0 : objGET_PROJECT_DETAILS_Result.Project_ID;
                var vInsertProjectDetails = db.INSERT_PROJECT_DETAILS(objGET_PROJECT_DETAILS_Result.Project_ID, objGET_PROJECT_DETAILS_Result.Project, objGET_PROJECT_DETAILS_Result.Start_Date, objGET_PROJECT_DETAILS_Result.End_Date, objGET_PROJECT_DETAILS_Result.Priority);

                db.SaveChanges();
                return Convert.ToString(vInsertProjectDetails);
            }

        }
        #endregion

    }
}
