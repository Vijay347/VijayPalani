﻿using System.Collections.Generic;
using System.Web.Http;
using System.Web.Http.Cors;
using Capsule_TaskManagerDL.Model;
using Capsule_TaskManagerBL;

namespace Capsule_TaskManager.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class ProjectController : ApiController
    {

        #region Public Declaration

        ProjectBL objProjectBL = null;

        #endregion

        #region GetProjectDetails
        /// <summary>
        /// To get project details
        /// </summary>
        /// <returns></returns>
        [Route("api/Project/GetProjectDetails")]
        [HttpGet]
        public IEnumerable<GET_PROJECT_DETAILS_Result> GetProjectDetails()
        {
            objProjectBL = new ProjectBL();
            var vGetProjectDetails = objProjectBL.GetProjectDetails();

            return vGetProjectDetails;
        }
        #endregion
        
        #region InsertProjectDetails
        /// <summary>
        /// Insert the project details which user entered
        /// </summary>
        /// <param name="objGET_PROJECT_DETAILS_Result"></param>
        /// <returns></returns>
        [Route("api/Project/InsertProjectDetails")]
        [HttpPost]
        public string InsertProjectDetails(GET_PROJECT_DETAILS_Result objGET_PROJECT_DETAILS_Result)
        {
            objProjectBL = new ProjectBL();
            var vInsertProjectDetails = objProjectBL.InsertProjectDetails(objGET_PROJECT_DETAILS_Result);
            return vInsertProjectDetails;
        }
        #endregion
    }
}
