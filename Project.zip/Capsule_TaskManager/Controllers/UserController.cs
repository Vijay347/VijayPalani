﻿using Capsule_TaskManagerBL;
using Capsule_TaskManagerDL.Model;
using System.Collections.Generic;
using System.Web.Http;
using System.Web.Http.Cors;

namespace Capsule_TaskManager.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class UserController : ApiController
    {
        #region Public Declaration

        UserBL objUserBL = null;

        #endregion

        #region GetUserDetails
        /// <summary>
        /// To get User details
        /// </summary>
        /// <returns></returns>
        [Route("api/User/GetUserDetails")]
        [HttpGet]
        public IEnumerable<GET_USER_DETAILS_Result> GetUserDetails()
        {
            objUserBL = new UserBL();
            var vGetUserDetails = objUserBL.GetUserDetails();

            return vGetUserDetails;
        }
        #endregion



        #region InsertUserDetails
        /// <summary>
        /// Insert the User details which user entered
        /// </summary>
        /// <param name="objGET_User_DETAILS_Result"></param>
        /// <returns></returns>
        [Route("api/User/InsertUserDetails")]
        [HttpPost]
        public string InsertUserDetails(GET_USER_DETAILS_Result objGET_User_DETAILS_Result)
        {
            objUserBL = new UserBL();
            var vInsertUserDetails = objUserBL.InsertUserDetails(objGET_User_DETAILS_Result);
            return vInsertUserDetails;
        }
        #endregion
    }
}
