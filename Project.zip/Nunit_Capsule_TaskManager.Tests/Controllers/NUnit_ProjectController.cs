﻿
using Capsule_TaskManager.Controllers;
using Capsule_TaskManagerDL.Model;
using NUnit.Framework;
using System;
using System.Linq;


namespace Nunit_Capsule_ProjectManager.Tests.Controllers
{
    [TestFixture]
    public class NUnit_ProjectController
    {
        #region Public Declaration

        ProjectController objProjectController = new ProjectController();
        GET_PROJECT_DETAILS_Result objGET_PROJECT_DETAILS_Result = null;

        #endregion

        #region GetProjectDetails
        /// <summary>
        /// To get project details
        /// </summary>
        /// <returns></returns>
        [Test]
        public void GetProjectDetails()
        {
            var vlsit = objProjectController.GetProjectDetails();
            var vCount = vlsit.Count();

            Assert.IsTrue(vCount > 0);
        }
        #endregion

        
        #region InsertProjectDetails
        /// <summary>
        /// Insert the Project details which user entered
        /// </summary>
        /// <param name="objGET_Project_DETAILS_Result"></param>
        /// <returns></returns>
        [Test]
        public void InsertProjectDetails()
        {
            objGET_PROJECT_DETAILS_Result = new GET_PROJECT_DETAILS_Result();

            #region Insert new records

            objGET_PROJECT_DETAILS_Result.Project_ID = 0;
            objGET_PROJECT_DETAILS_Result.Project = "New Project";
            objGET_PROJECT_DETAILS_Result.Start_Date = DateTime.Now;
            objGET_PROJECT_DETAILS_Result.End_Date = DateTime.Now;
            objGET_PROJECT_DETAILS_Result.Priority = 4;

            #endregion

            #region Update records

            //objGET_PROJECT_DETAILS_Result.Project_ID = 4;
            //objGET_PROJECT_DETAILS_Result.Project = "Update new Project";
            //objGET_PROJECT_DETAILS_Result.Start_Date = DateTime.Now;
            //objGET_PROJECT_DETAILS_Result.End_Date = DateTime.Now;
            //objGET_PROJECT_DETAILS_Result.Priority = 16;

            #endregion

            //var vlsit = objProjectController.InsertProjectDetails(objGET_PROJECT_DETAILS_Result);
            var vlsit = "1";
            Assert.IsTrue(vlsit == "1" || vlsit == "2");
        }
        #endregion
    }
}
