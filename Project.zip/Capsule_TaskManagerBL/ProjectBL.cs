﻿using Capsule_TaskManagerDL;
using Capsule_TaskManagerDL.Model;
using System.Collections.Generic;

namespace Capsule_TaskManagerBL
{
    public class ProjectBL
    {

        #region Public Declaration

        ProjectDL objProjectDL = null;

        #endregion

        #region GetProjectDetails
        /// <summary>
        /// To get project details from DL using EF
        /// </summary>
        /// <returns></returns>

        public IEnumerable<GET_PROJECT_DETAILS_Result> GetProjectDetails()
        {
            objProjectDL = new ProjectDL();
            var vGetProjectDetails = objProjectDL.GetProjectDetails();

            return vGetProjectDetails;
        }
        #endregion


        #region InsertProjectDetails
        /// <summary>
        /// Insert the project values which user entered to DB from DL using EF
        /// </summary>
        /// <param name="objGET_PROJECT_DETAILS_Result"></param>
        /// <returns></returns>
        public string InsertProjectDetails(GET_PROJECT_DETAILS_Result objGET_PROJECT_DETAILS_Result)
        {
            objProjectDL = new ProjectDL();
            var vInsertProjectDetails = objProjectDL.InsertProjectDetails(objGET_PROJECT_DETAILS_Result);

            if (objGET_PROJECT_DETAILS_Result.Project_ID != 0)
            {
                if (vInsertProjectDetails == "1")
                {
                    vInsertProjectDetails = "2";
                }
            }

            return vInsertProjectDetails;
        }
        #endregion

    }
}
