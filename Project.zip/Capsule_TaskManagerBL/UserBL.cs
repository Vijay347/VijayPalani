﻿using Capsule_TaskManagerDL;
using Capsule_TaskManagerDL.Model;
using System.Collections.Generic;

namespace Capsule_TaskManagerBL
{
    public class UserBL
    {
        #region Public Declaration

        UserDL objUserDL = null;

        #endregion

        #region GetUserDetails
        /// <summary>
        /// To get User details from DL using EF
        /// </summary>
        /// <returns></returns>

        public IEnumerable<GET_USER_DETAILS_Result> GetUserDetails()
        {
            objUserDL = new UserDL();
            var vGetUserDetails = objUserDL.GetUserDetails();

            return vGetUserDetails;
        }
        #endregion


        #region InsertUserDetails
        /// <summary>
        /// Insert the User values which user entered to DB from DL using EF
        /// </summary>
        /// <param name="objGET_User_DETAILS_Result"></param>
        /// <returns></returns>
        public string InsertUserDetails(GET_USER_DETAILS_Result objGET_User_DETAILS_Result)
        {
            objUserDL = new UserDL();
            var vInsertUserDetails = objUserDL.InsertUserDetails(objGET_User_DETAILS_Result);

            if (objGET_User_DETAILS_Result.User_ID != 0)
            {
                if (vInsertUserDetails == "1")
                {
                    vInsertUserDetails = "2";
                }
            }

            return vInsertUserDetails;
        }
        #endregion
    }
}
